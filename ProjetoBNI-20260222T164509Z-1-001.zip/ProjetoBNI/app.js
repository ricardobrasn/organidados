// Estado global da aplicação
const appState = {
    currentUser: null,
    currentPage: 'landing',
    offers: [
        {
            id: 1,
            title: 'Consultoria Jurídica - 50% OFF',
            provider: 'Dr. João Silva',
            category: 'Jurídico',
            discount: '50%',
            originalPrice: 'R$ 300,00',
            finalPrice: 'R$ 150,00',
            description: 'Consultoria jurídica especializada em direito empresarial',
            validUntil: '2026-03-31',
            status: 'approved',
            terms: 'Válido para primeira consulta. Agendamento obrigatório.',
            image: 'https://images.unsplash.com/photo-1589829545856-d10d557cf95f?w=400&h=250&fit=crop&crop=center'
        },
        {
            id: 2,
            title: 'Marketing Digital - Pacote Completo',
            provider: 'Maria Santos',
            category: 'Marketing',
            discount: '30%',
            originalPrice: 'R$ 2.000,00',
            finalPrice: 'R$ 1.400,00',
            description: 'Pacote completo de marketing digital para pequenas empresas',
            validUntil: '2026-04-15',
            status: 'approved',
            terms: 'Inclui estratégia, criação de conteúdo e gestão por 3 meses.',
            image: 'https://images.unsplash.com/photo-1460925895917-afdab827c52f?w=400&h=250&fit=crop&crop=center'
        },
        {
            id: 3,
            title: 'Consultoria Contábil - 40% OFF',
            provider: 'Pedro Costa',
            category: 'Contabilidade',
            discount: '40%',
            originalPrice: 'R$ 500,00',
            finalPrice: 'R$ 300,00',
            description: 'Consultoria contábil completa para pequenas empresas',
            validUntil: '2026-05-20',
            status: 'approved',
            terms: 'Inclui análise fiscal e planejamento tributário.',
            image: 'https://images.unsplash.com/photo-1554224155-6726b3ff858f?w=400&h=250&fit=crop&crop=center'
        },
        {
            id: 4,
            title: 'Design Gráfico - Identidade Visual',
            provider: 'Ana Silva',
            category: 'Design',
            discount: '35%',
            originalPrice: 'R$ 800,00',
            finalPrice: 'R$ 520,00',
            description: 'Criação completa de identidade visual para sua empresa',
            validUntil: '2026-04-30',
            status: 'approved',
            terms: 'Inclui logo, cartão de visita e papelaria básica.',
            image: 'https://images.unsplash.com/photo-1561070791-2526d30994b5?w=400&h=250&fit=crop&crop=center'
        }
    ],
    userRedemptions: [],
    inviteCodes: {
        'PILOT2026': { uses: 2, maxUses: 3, sponsor: 'João Silva' },
        'BCLUB001': { uses: 1, maxUses: 3, sponsor: 'Maria Santos' }
    }
};

// Simulação de dados de usuários BNI
const bniMembers = {
    'joao@empresa.com': { 
        name: 'João Silva', 
        status: 'active', 
        semaforo: 85, 
        debts: false,
        eligible: true 
    },
    'maria@marketing.com': { 
        name: 'Maria Santos', 
        status: 'active', 
        semaforo: 75, 
        debts: false,
        eligible: true 
    },
    'pedro@consultoria.com': { 
        name: 'Pedro Costa', 
        status: 'active', 
        semaforo: 65, 
        debts: true,
        eligible: false 
    }
};

// Funções de navegação
function showPage(pageId) {
    document.querySelectorAll('.page').forEach(page => {
        page.classList.remove('active');
    });
    document.getElementById(pageId).classList.add('active');
    appState.currentPage = pageId;
}

function showModal(modalId) {
    document.getElementById(modalId).classList.add('active');
}

function closeModal(modalId) {
    const modal = document.getElementById(modalId);
    if (modal) {
        modal.classList.remove('active');
    }
}

function showLogin() {
    showModal('login-modal');
}

function showRegister() {
    showModal('register-modal');
}

// Funções de autenticação
function handleLogin(event) {
    event.preventDefault();
    const email = document.getElementById('email').value;
    
    // Simular login
    if (bniMembers[email]) {
        appState.currentUser = {
            email: email,
            ...bniMembers[email],
            type: 'bni'
        };
    } else {
        appState.currentUser = {
            email: email,
            name: 'Usuário Comunidade',
            type: 'community'
        };
    }
    
    closeModal('login-modal');
    showDashboard();
}

function showBNIRegister() {
    closeModal('register-modal');
    document.body.insertAdjacentHTML('beforeend', `
        <div id="bni-register-modal" class="modal active">
            <div class="modal-content">
                <div class="modal-header">
                    <h2>Adesão Membro BNI</h2>
                    <button class="close-btn" onclick="closeModal('bni-register-modal')">&times;</button>
                </div>
                <form onsubmit="handleBNIRegister(event)">
                    <div class="form-group">
                        <label for="bni-email">E-mail BNI</label>
                        <input type="email" id="bni-email" required>
                    </div>
                    <div class="form-group">
                        <label for="bni-password">Senha</label>
                        <input type="password" id="bni-password" required>
                    </div>
                    <div class="form-group">
                        <label for="bni-name">Nome Completo</label>
                        <input type="text" id="bni-name" required>
                    </div>
                    <div class="form-group">
                        <label for="bni-phone">Telefone</label>
                        <input type="tel" id="bni-phone" required>
                    </div>
                    <div class="form-group">
                        <input type="checkbox" id="terms" required>
                        <label for="terms">Aceito os termos e condições do BClub</label>
                    </div>
                    <button type="submit" class="btn btn-primary btn-full">Verificar Elegibilidade</button>
                </form>
            </div>
        </div>
    `);
}

function showCommunityRegister() {
    closeModal('register-modal');
    document.body.insertAdjacentHTML('beforeend', `
        <div id="community-register-modal" class="modal active">
            <div class="modal-content">
                <div class="modal-header">
                    <h2>Adesão com Código de Convite</h2>
                    <button class="close-btn" onclick="closeModal('community-register-modal')">&times;</button>
                </div>
                <form onsubmit="handleCommunityRegister(event)">
                    <div class="form-group">
                        <label for="invite-code">Código de Convite</label>
                        <input type="text" id="invite-code" placeholder="Ex: PILOT2026" required>
                    </div>
                    <div class="form-group">
                        <label for="comm-email">E-mail</label>
                        <input type="email" id="comm-email" required>
                    </div>
                    <div class="form-group">
                        <label for="comm-password">Senha</label>
                        <input type="password" id="comm-password" required>
                    </div>
                    <div class="form-group">
                        <label for="comm-name">Nome Completo</label>
                        <input type="text" id="comm-name" required>
                    </div>
                    <div class="form-group">
                        <label for="comm-phone">Telefone</label>
                        <input type="tel" id="comm-phone" required>
                    </div>
                    <div class="form-group">
                        <input type="checkbox" id="comm-terms" required>
                        <label for="comm-terms">Aceito os termos e condições do BClub</label>
                    </div>
                    <button type="submit" class="btn btn-primary btn-full">Cadastrar</button>
                </form>
            </div>
        </div>
    `);
}

function handleBNIRegister(event) {
    event.preventDefault();
    const email = document.getElementById('bni-email').value;
    const name = document.getElementById('bni-name').value;
    
    // Verificar elegibilidade
    const member = bniMembers[email];
    
    closeModal('bni-register-modal');
    
    if (member && member.eligible) {
        showEligibilityResult(true, member);
    } else if (member && !member.eligible) {
        showEligibilityResult(false, member);
    } else {
        showEligibilityResult(false, null);
    }
}

function handleCommunityRegister(event) {
    event.preventDefault();
    const code = document.getElementById('invite-code').value;
    const email = document.getElementById('comm-email').value;
    const name = document.getElementById('comm-name').value;
    
    closeModal('community-register-modal');
    
    if (appState.inviteCodes[code] && appState.inviteCodes[code].uses < appState.inviteCodes[code].maxUses) {
        appState.inviteCodes[code].uses++;
        appState.currentUser = {
            email: email,
            name: name,
            type: 'community',
            sponsor: appState.inviteCodes[code].sponsor
        };
        showDashboard();
    } else {
        alert('Código de convite inválido ou esgotado!');
    }
}

function showEligibilityResult(eligible, member) {
    const resultHtml = eligible ? `
        <div class="modal active" id="eligibility-result">
            <div class="modal-content">
                <div class="modal-header">
                    <h2>✅ Elegível para o BClub</h2>
                </div>
                <div style="text-align: center; padding: 2rem;">
                    <div class="status-badge status-approved" style="font-size: 1.2rem; padding: 1rem 2rem;">
                        APROVADO
                    </div>
                    <h3 style="margin: 2rem 0 1rem;">Parabéns, ${member.name}!</h3>
                    <p>Você atende todos os critérios:</p>
                    <ul style="text-align: left; margin: 1rem 0; max-width: 300px; margin-left: auto; margin-right: auto;">
                        <li>✅ Membro BNI ativo</li>
                        <li>✅ Semáforo: ${member.semaforo} (≥70)</li>
                        <li>✅ Sem pendências financeiras</li>
                    </ul>
                    <button class="btn btn-primary" onclick="completeRegistration()">
                        Finalizar Cadastro
                    </button>
                </div>
            </div>
        </div>
    ` : `
        <div class="modal active" id="eligibility-result">
            <div class="modal-content">
                <div class="modal-header">
                    <h2>❌ Não Elegível</h2>
                </div>
                <div style="text-align: center; padding: 2rem;">
                    <div class="status-badge status-rejected" style="font-size: 1.2rem; padding: 1rem 2rem;">
                        REPROVADO
                    </div>
                    <h3 style="margin: 2rem 0 1rem;">Critérios não atendidos</h3>
                    <ul style="text-align: left; margin: 1rem 0; max-width: 300px; margin-left: auto; margin-right: auto;">
                        ${member ? `
                            <li>${member.status === 'active' ? '✅' : '❌'} Membro BNI ativo</li>
                            <li>${member.semaforo >= 70 ? '✅' : '❌'} Semáforo: ${member.semaforo} (≥70)</li>
                            <li>${!member.debts ? '✅' : '❌'} Sem pendências financeiras</li>
                        ` : '<li>❌ E-mail não encontrado na base BNI</li>'}
                    </ul>
                    <p style="margin-top: 2rem;">Entre em contato com a administração do capítulo para mais informações.</p>
                    <button class="btn btn-outline" onclick="closeModal('eligibility-result')">
                        Fechar
                    </button>
                </div>
            </div>
        </div>
    `;
    
    document.body.insertAdjacentHTML('beforeend', resultHtml);
}

function completeRegistration() {
    const email = document.getElementById('bni-email').value;
    appState.currentUser = {
        email: email,
        ...bniMembers[email],
        type: 'bni'
    };
    closeModal('eligibility-result');
    showDashboard();
}

function showDashboard() {
    const userType = appState.currentUser.type;
    
    if (userType === 'bni' || userType === 'community') {
        showConsumerDashboard();
    } else if (userType === 'provider') {
        showProviderDashboard();
    } else if (userType === 'admin') {
        showAdminDashboard();
    }
}

// Inicialização
document.addEventListener('DOMContentLoaded', function() {
    // Página inicial ativa
    showPage('landing-page');
    
    // Carregar scripts dos dashboards
    loadScript('consumer-functions.js');
    loadScript('provider-functions.js');
    loadScript('admin-functions.js');
});

// Função para carregar scripts dinamicamente
function loadScript(src) {
    const script = document.createElement('script');
    script.src = src;
    document.head.appendChild(script);
}

// Funções utilitárias
function formatCurrency(value) {
    return new Intl.NumberFormat('pt-BR', {
        style: 'currency',
        currency: 'BRL'
    }).format(value);
}

function formatDate(dateString) {
    return new Date(dateString).toLocaleDateString('pt-BR');
}

// Função para demonstração - permite trocar entre tipos de usuário
function switchUserType(type) {
    if (type === 'consumer') {
        appState.currentUser = {
            email: 'joao@empresa.com',
            name: 'João Silva',
            type: 'bni'
        };
        showConsumerDashboard();
    } else if (type === 'provider') {
        showProviderDashboard();
    } else if (type === 'admin') {
        showAdminDashboard();
    }
}