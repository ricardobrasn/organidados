// Funções específicas do dashboard do consumidor

let selectedOfferId = null;
let selectedRedemptionId = null;

function showConsumerDashboard() {
    // Criar o HTML do dashboard do consumidor diretamente
    const dashboardHtml = `
        <!-- Consumer Dashboard -->
        <div id="consumer-dashboard" class="page dashboard">
            <aside class="sidebar">
                <div class="sidebar-header">
                    <div class="logo">
                        <img src="https://zoom.us/account/branding/p/f2351d47-c162-442e-be90-1419d6b4b230.png" alt="BNI Logo" class="bni-logo-sidebar">
                        <div class="logo-text">
                            <h2>BClub</h2>
                            <span class="user-info" id="user-welcome"></span>
                        </div>
                    </div>
                </div>
                <nav>
                    <ul class="sidebar-nav">
                        <li><a href="#" onclick="showConsumerSection('catalog')" class="active">
                            <i class="fas fa-store"></i> Catálogo
                        </a></li>
                        <li><a href="#" onclick="showConsumerSection('my-redemptions')">
                            <i class="fas fa-ticket-alt"></i> Meus Resgates
                        </a></li>
                        <li><a href="#" onclick="showConsumerSection('profile')">
                            <i class="fas fa-user"></i> Meu Perfil
                        </a></li>
                        <li><a href="#" onclick="logout()">
                            <i class="fas fa-sign-out-alt"></i> Sair
                        </a></li>
                    </ul>
                </nav>
            </aside>

            <main class="main-content">
                <!-- Catálogo de Ofertas -->
                <div id="catalog-section" class="section active">
                    <div class="page-header">
                        <h1>Catálogo de Ofertas</h1>
                        <p>Explore os benefícios exclusivos disponíveis para você</p>
                    </div>

                    <div class="filters-bar">
                        <div class="search-box">
                            <input type="text" placeholder="Buscar ofertas..." id="search-input">
                            <i class="fas fa-search"></i>
                        </div>
                        <select id="category-filter">
                            <option value="">Todas as categorias</option>
                            <option value="Jurídico">Jurídico</option>
                            <option value="Marketing">Marketing</option>
                            <option value="Consultoria">Consultoria</option>
                            <option value="Tecnologia">Tecnologia</option>
                        </select>
                        <div class="redemption-counter">
                            <span class="counter-label">Resgates este mês:</span>
                            <span class="counter-value" id="monthly-redemptions">0/2</span>
                        </div>
                    </div>

                    <div class="offers-grid" id="offers-grid">
                        <!-- Ofertas serão carregadas dinamicamente -->
                    </div>
                </div>

                <!-- Meus Resgates -->
                <div id="my-redemptions-section" class="section">
                    <div class="page-header">
                        <h1>Meus Resgates</h1>
                        <p>Acompanhe o status dos seus benefícios resgatados</p>
                    </div>

                    <div class="redemptions-list" id="redemptions-list">
                        <!-- Resgates serão carregados dinamicamente -->
                    </div>
                </div>

                <!-- Perfil -->
                <div id="profile-section" class="section">
                    <div class="page-header">
                        <h1>Meu Perfil</h1>
                        <p>Informações da sua conta no BClub</p>
                    </div>

                    <div class="grid grid-2">
                        <div class="card">
                            <div class="card-header">
                                <h3 class="card-title">Informações Pessoais</h3>
                            </div>
                            <div class="profile-info" id="profile-info">
                                <!-- Informações serão carregadas dinamicamente -->
                            </div>
                        </div>

                        <div class="card">
                            <div class="card-header">
                                <h3 class="card-title">Estatísticas</h3>
                            </div>
                            <div class="stats-grid">
                                <div class="stat-item">
                                    <div class="stat-number" id="total-redemptions">0</div>
                                    <div class="stat-label">Total de Resgates</div>
                                </div>
                                <div class="stat-item">
                                    <div class="stat-number" id="monthly-limit">2</div>
                                    <div class="stat-label">Limite Mensal</div>
                                </div>
                                <div class="stat-item">
                                    <div class="stat-number" id="savings-total">R$ 0</div>
                                    <div class="stat-label">Economia Total</div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </main>
        </div>

        <!-- Modal de Detalhes da Oferta -->
        <div id="offer-details-modal" class="modal">
            <div class="modal-content modal-large">
                <div class="modal-header">
                    <h2 id="offer-title">Título da Oferta</h2>
                    <button class="close-btn" onclick="closeModal('offer-details-modal')">&times;</button>
                </div>
                <div class="offer-details-content" id="offer-details-content">
                    <!-- Conteúdo será carregado dinamicamente -->
                </div>
            </div>
        </div>

        <!-- Modal de Confirmação de Resgate -->
        <div id="redeem-confirmation-modal" class="modal">
            <div class="modal-content">
                <div class="modal-header">
                    <h2>Confirmar Resgate</h2>
                    <button class="close-btn" onclick="closeModal('redeem-confirmation-modal')">&times;</button>
                </div>
                <div class="confirmation-content">
                    <div class="warning-box">
                        <i class="fas fa-exclamation-triangle"></i>
                        <p>Você tem certeza que deseja resgatar este benefício?</p>
                        <p><strong>Esta ação não pode ser desfeita.</strong></p>
                    </div>
                    <div class="offer-summary" id="redeem-offer-summary">
                        <!-- Resumo da oferta -->
                    </div>
                    <div class="modal-actions">
                        <button class="btn btn-outline" onclick="closeModal('redeem-confirmation-modal')">
                            Cancelar
                        </button>
                        <button class="btn btn-primary" onclick="confirmRedemption()">
                            Confirmar Resgate
                        </button>
                    </div>
                </div>
            </div>
        </div>

        <!-- Modal de Upload de Comprovante -->
        <div id="upload-proof-modal" class="modal">
            <div class="modal-content">
                <div class="modal-header">
                    <h2>Enviar Comprovante</h2>
                    <button class="close-btn" onclick="closeModal('upload-proof-modal')">&times;</button>
                </div>
                <form onsubmit="handleProofUpload(event)">
                    <div class="form-group">
                        <label>Comprovante de Utilização</label>
                        <div class="file-upload-area" onclick="document.getElementById('proof-file').click()">
                            <i class="fas fa-cloud-upload-alt"></i>
                            <p>Clique para selecionar arquivo</p>
                            <small>Formatos aceitos: JPG, PNG, PDF (máx. 5MB)</small>
                        </div>
                        <input type="file" id="proof-file" accept=".jpg,.jpeg,.png,.pdf" style="display: none;">
                    </div>
                    <div class="form-group">
                        <label for="proof-notes">Observações (opcional)</label>
                        <textarea id="proof-notes" rows="3" placeholder="Adicione informações sobre a utilização do benefício..."></textarea>
                    </div>
                    <div class="modal-actions">
                        <button type="button" class="btn btn-outline" onclick="closeModal('upload-proof-modal')">
                            Cancelar
                        </button>
                        <button type="submit" class="btn btn-primary">
                            Enviar Comprovante
                        </button>
                    </div>
                </form>
            </div>
        </div>
    `;
    
    document.body.insertAdjacentHTML('beforeend', dashboardHtml);
    initializeConsumerDashboard();
}

function initializeConsumerDashboard() {
    showPage('consumer-dashboard');
    
    // Inicializar array de resgates se não existir
    if (!appState.userRedemptions) {
        appState.userRedemptions = [];
    }
    
    // Debug - adicionar um resgate de exemplo para teste
    console.log('Inicializando dashboard do consumidor');
    console.log('Resgates atuais:', appState.userRedemptions);
    
    // Adicionar um resgate de teste se não houver nenhum
    if (appState.userRedemptions.length === 0) {
        const testRedemption = {
            id: 999,
            offerId: 1,
            offerTitle: 'Teste - Consultoria Jurídica',
            provider: 'Dr. João Silva',
            finalPrice: 'R$ 150,00',
            redemptionCode: 'BC999999',
            status: 'redeemed',
            redeemedAt: new Date().toISOString(),
            proofUploaded: false,
            providerConfirmed: false
        };
        appState.userRedemptions.push(testRedemption);
        console.log('Resgate de teste adicionado:', testRedemption);
    }
    
    updateUserWelcome();
    loadOffers();
    loadUserRedemptions();
    updateRedemptionCounter();
    showConsumerSection('catalog');
}

function updateUserWelcome() {
    const welcomeEl = document.getElementById('user-welcome');
    if (welcomeEl) {
        welcomeEl.textContent = `Olá, ${appState.currentUser.name}`;
    }
}

function showConsumerSection(sectionId) {
    console.log('=== SHOW CONSUMER SECTION ===');
    console.log('Seção solicitada:', sectionId);
    
    // Remover classe active de todas as seções
    document.querySelectorAll('.section').forEach(section => {
        section.classList.remove('active');
    });
    
    // Remover classe active de todos os links da sidebar
    document.querySelectorAll('.sidebar-nav a').forEach(link => {
        link.classList.remove('active');
    });
    
    // Ativar seção correspondente
    const targetSection = document.getElementById(`${sectionId}-section`);
    console.log('Seção encontrada:', !!targetSection);
    if (targetSection) {
        targetSection.classList.add('active');
        console.log('Seção ativada:', targetSection.id);
    }
    
    // Ativar link correspondente na sidebar
    const targetLink = document.querySelector(`[onclick="showConsumerSection('${sectionId}')"]`);
    console.log('Link encontrado:', !!targetLink);
    if (targetLink) {
        targetLink.classList.add('active');
    }
    
    // Carregar dados específicos da seção
    if (sectionId === 'catalog') {
        console.log('Carregando ofertas');
        loadOffers();
    } else if (sectionId === 'my-redemptions') {
        console.log('Carregando resgates do usuário');
        loadUserRedemptions();
    } else if (sectionId === 'profile') {
        console.log('Carregando perfil do usuário');
        loadUserProfile();
    }
}

function loadOffers() {
    const offersGrid = document.getElementById('offers-grid');
    if (!offersGrid) return;
    
    const offersHtml = appState.offers.map(offer => `
        <div class="offer-card" onclick="showOfferDetails(${offer.id})">
            <div class="offer-image">
                <img src="${offer.image}" alt="${offer.title}">
                <div class="discount-badge">${offer.discount}</div>
            </div>
            <div class="offer-content">
                <div class="offer-category">${offer.category}</div>
                <h3 class="offer-title">${offer.title}</h3>
                <div class="offer-provider">por ${offer.provider}</div>
                <div class="offer-pricing">
                    <span class="original-price">${offer.originalPrice}</span>
                    <span class="final-price">${offer.finalPrice}</span>
                </div>
                <div class="offer-validity">
                    Válido até ${formatDate(offer.validUntil)}
                </div>
                <button class="btn btn-primary btn-full offer-btn">
                    Ver Detalhes
                </button>
            </div>
        </div>
    `).join('');
    
    offersGrid.innerHTML = offersHtml;
}

function showOfferDetails(offerId) {
    const offer = appState.offers.find(o => o.id === offerId);
    if (!offer) return;
    
    selectedOfferId = offerId;
    
    const modal = document.getElementById('offer-details-modal');
    const titleEl = document.getElementById('offer-title');
    const contentEl = document.getElementById('offer-details-content');
    
    titleEl.textContent = offer.title;
    
    const canRedeem = getUserMonthlyRedemptions() < 2;
    
    contentEl.innerHTML = `
        <div class="offer-details-grid">
            <div class="offer-main-info">
                <img src="${offer.image}" alt="${offer.title}" class="offer-detail-image">
                <div class="offer-pricing-detail">
                    <div class="pricing-row">
                        <span class="label">Preço original:</span>
                        <span class="original-price">${offer.originalPrice}</span>
                    </div>
                    <div class="pricing-row">
                        <span class="label">Desconto:</span>
                        <span class="discount">${offer.discount}</span>
                    </div>
                    <div class="pricing-row final">
                        <span class="label">Preço final:</span>
                        <span class="final-price">${offer.finalPrice}</span>
                    </div>
                </div>
            </div>
            
            <div class="offer-info">
                <div class="info-section">
                    <h4>Descrição</h4>
                    <p>${offer.description}</p>
                </div>
                
                <div class="info-section">
                    <h4>Fornecedor</h4>
                    <p>${offer.provider}</p>
                </div>
                
                <div class="info-section">
                    <h4>Categoria</h4>
                    <p>${offer.category}</p>
                </div>
                
                <div class="info-section">
                    <h4>Validade</h4>
                    <p>Até ${formatDate(offer.validUntil)}</p>
                </div>
                
                <div class="info-section">
                    <h4>Termos e Condições</h4>
                    <p>${offer.terms}</p>
                </div>
            </div>
        </div>
        
        <div class="modal-actions">
            ${canRedeem ? `
                <button class="btn btn-primary btn-large" onclick="showRedeemConfirmation(${offer.id})">
                    <i class="fas fa-ticket-alt"></i>
                    Resgatar Benefício
                </button>
            ` : `
                <div class="limit-warning">
                    <i class="fas fa-exclamation-circle"></i>
                    Você atingiu o limite de 2 resgates por mês
                </div>
            `}
        </div>
    `;
    
    showModal('offer-details-modal');
}

function showRedeemConfirmation(offerId) {
    const offer = appState.offers.find(o => o.id === offerId);
    if (!offer) return;
    
    closeModal('offer-details-modal');
    
    const summaryEl = document.getElementById('redeem-offer-summary');
    summaryEl.innerHTML = `
        <div class="redeem-summary">
            <h4>${offer.title}</h4>
            <p><strong>Fornecedor:</strong> ${offer.provider}</p>
            <p><strong>Valor:</strong> ${offer.finalPrice} (${offer.discount} de desconto)</p>
            <p><strong>Validade:</strong> ${formatDate(offer.validUntil)}</p>
        </div>
        <div class="redemption-info">
            <p><strong>Importante:</strong></p>
            <ul>
                <li>Após o resgate, você terá um código único para apresentar ao fornecedor</li>
                <li>Você deve enviar comprovante de utilização em até 7 dias</li>
                <li>O fornecedor confirmará a utilização do benefício</li>
            </ul>
        </div>
    `;
    
    showModal('redeem-confirmation-modal');
}

function confirmRedemption() {
    const offer = appState.offers.find(o => o.id === selectedOfferId);
    if (!offer) {
        console.error('Oferta não encontrada:', selectedOfferId);
        return;
    }
    
    // Gerar código de resgate único
    const redemptionCode = 'BC' + Date.now().toString().slice(-6);
    
    // Criar novo resgate
    const newRedemption = {
        id: Date.now(),
        offerId: selectedOfferId,
        offerTitle: offer.title,
        provider: offer.provider,
        finalPrice: offer.finalPrice,
        redemptionCode: redemptionCode,
        status: 'redeemed',
        redeemedAt: new Date().toISOString(),
        proofUploaded: false,
        providerConfirmed: false
    };
    
    // Inicializar array se não existir
    if (!appState.userRedemptions) {
        appState.userRedemptions = [];
    }
    
    // Adicionar ao estado
    appState.userRedemptions.push(newRedemption);
    
    // Debug - verificar se foi adicionado
    console.log('Resgate adicionado:', newRedemption);
    console.log('Total de resgates:', appState.userRedemptions.length);
    
    closeModal('redeem-confirmation-modal');
    
    // Mostrar código de resgate
    showRedemptionSuccess(newRedemption);
    
    // Atualizar contador
    updateRedemptionCounter();
}

function showRedemptionSuccess(redemption) {
    // Remover modal anterior se existir
    const existingModal = document.getElementById('redemption-success-modal');
    if (existingModal) {
        existingModal.remove();
    }
    
    const successHtml = `
        <div class="modal active" id="redemption-success-modal">
            <div class="modal-content">
                <div class="modal-header">
                    <h2>✅ Resgate Realizado com Sucesso!</h2>
                </div>
                <div class="success-content">
                    <div class="redemption-code-display">
                        <h3>Seu Código de Resgate</h3>
                        <div class="code-box">
                            <span class="code">${redemption.redemptionCode}</span>
                            <button class="copy-btn" onclick="copyToClipboard('${redemption.redemptionCode}')">
                                <i class="fas fa-copy"></i>
                            </button>
                        </div>
                    </div>
                    
                    <div class="next-steps">
                        <h4>Próximos Passos:</h4>
                        <ol>
                            <li>Apresente este código ao fornecedor: <strong>${redemption.provider}</strong></li>
                            <li>Utilize o benefício conforme os termos</li>
                            <li>Envie o comprovante de utilização em até 7 dias</li>
                        </ol>
                    </div>
                    
                    <div class="modal-actions">
                        <button class="btn btn-outline" onclick="closeRedemptionSuccessModal()">
                            Fechar
                        </button>
                        <button class="btn btn-primary" onclick="goToMyRedemptions()">
                            Ver Meus Resgates
                        </button>
                    </div>
                </div>
            </div>
        </div>
    `;
    
    document.body.insertAdjacentHTML('beforeend', successHtml);
}

function closeRedemptionSuccessModal() {
    const modal = document.getElementById('redemption-success-modal');
    if (modal) {
        modal.remove();
    }
}

function copyToClipboard(text) {
    navigator.clipboard.writeText(text).then(() => {
        // Feedback visual
        const copyBtn = event.target.closest('.copy-btn');
        const originalHtml = copyBtn.innerHTML;
        copyBtn.innerHTML = '<i class="fas fa-check"></i>';
        setTimeout(() => {
            copyBtn.innerHTML = originalHtml;
        }, 2000);
    });
}

function goToMyRedemptions() {
    console.log('=== NAVEGANDO PARA MEUS RESGATES ===');
    console.log('Resgates disponíveis:', appState.userRedemptions);
    console.log('Número de resgates:', appState.userRedemptions ? appState.userRedemptions.length : 0);
    
    // Fechar modal se existir
    const modal = document.getElementById('redemption-success-modal');
    if (modal) {
        console.log('Removendo modal de sucesso');
        modal.remove();
    }
    
    // Navegar para seção de resgates
    console.log('Chamando showConsumerSection com my-redemptions');
    showConsumerSection('my-redemptions');
    
    // Verificar se a seção foi ativada
    setTimeout(() => {
        const section = document.getElementById('my-redemptions-section');
        const isActive = section && section.classList.contains('active');
        console.log('Seção my-redemptions ativa:', isActive);
        
        const redemptionsList = document.getElementById('redemptions-list');
        console.log('Elemento redemptions-list encontrado:', !!redemptionsList);
        if (redemptionsList) {
            console.log('Conteúdo atual da lista:', redemptionsList.innerHTML.substring(0, 100));
        }
    }, 100);
}

function loadUserRedemptions() {
    console.log('=== LOAD USER REDEMPTIONS ===');
    
    const redemptionsList = document.getElementById('redemptions-list');
    if (!redemptionsList) {
        console.error('Elemento redemptions-list não encontrado');
        console.log('Elementos disponíveis com ID:', Array.from(document.querySelectorAll('[id]')).map(el => el.id));
        return;
    }
    
    console.log('Elemento redemptions-list encontrado');
    
    // Debug - verificar estado dos resgates
    console.log('Estado do appState.userRedemptions:', appState.userRedemptions);
    console.log('Tipo:', typeof appState.userRedemptions);
    console.log('É array:', Array.isArray(appState.userRedemptions));
    console.log('Número de resgates:', appState.userRedemptions ? appState.userRedemptions.length : 0);
    
    if (!appState.userRedemptions || appState.userRedemptions.length === 0) {
        console.log('Nenhum resgate encontrado, mostrando empty state');
        redemptionsList.innerHTML = `
            <div class="empty-state">
                <i class="fas fa-ticket-alt"></i>
                <h3>Nenhum resgate realizado</h3>
                <p>Explore o catálogo e resgate seus primeiros benefícios!</p>
                <button class="btn btn-primary" onclick="showConsumerSection('catalog')">
                    Ver Catálogo
                </button>
            </div>
        `;
        return;
    }
    
    console.log('Renderizando', appState.userRedemptions.length, 'resgates');
    
    const redemptionsHtml = appState.userRedemptions.map((redemption, index) => {
        console.log(`Renderizando resgate ${index + 1}:`, redemption);
        return `
            <div class="redemption-card">
                <div class="redemption-header">
                    <h3>${redemption.offerTitle}</h3>
                    <span class="status-badge ${getStatusClass(redemption.status)}">
                        ${getStatusText(redemption.status)}
                    </span>
                </div>
                
                <div class="redemption-details">
                    <div class="detail-row">
                        <span class="label">Fornecedor:</span>
                        <span>${redemption.provider}</span>
                    </div>
                    <div class="detail-row">
                        <span class="label">Valor:</span>
                        <span>${redemption.finalPrice}</span>
                    </div>
                    <div class="detail-row">
                        <span class="label">Código:</span>
                        <span class="redemption-code">${redemption.redemptionCode}</span>
                    </div>
                    <div class="detail-row">
                        <span class="label">Data:</span>
                        <span>${formatDate(redemption.redeemedAt)}</span>
                    </div>
                </div>
                
                <div class="redemption-actions">
                    ${getRedemptionActions(redemption)}
                </div>
            </div>
        `;
    }).join('');
    
    console.log('HTML gerado:', redemptionsHtml.substring(0, 200) + '...');
    redemptionsList.innerHTML = redemptionsHtml;
    console.log('HTML inserido no DOM');
}

function getStatusClass(status) {
    const statusMap = {
        'redeemed': 'status-warning',
        'proof-uploaded': 'status-pending',
        'confirmed': 'status-approved',
        'disputed': 'status-rejected'
    };
    return statusMap[status] || 'status-pending';
}

function getStatusText(status) {
    const statusMap = {
        'redeemed': 'Resgatado',
        'proof-uploaded': 'Comprovante Enviado',
        'confirmed': 'Confirmado',
        'disputed': 'Em Disputa'
    };
    return statusMap[status] || 'Pendente';
}

function getRedemptionActions(redemption) {
    if (redemption.status === 'redeemed') {
        return `
            <button class="btn btn-primary btn-sm" onclick="showUploadProof(${redemption.id})">
                <i class="fas fa-upload"></i>
                Enviar Comprovante
            </button>
        `;
    } else if (redemption.status === 'proof-uploaded') {
        return `
            <span class="status-info">
                <i class="fas fa-clock"></i>
                Aguardando confirmação do fornecedor
            </span>
        `;
    } else if (redemption.status === 'confirmed') {
        return `
            <span class="status-info success">
                <i class="fas fa-check-circle"></i>
                Benefício confirmado
            </span>
        `;
    }
    return '';
}

function showUploadProof(redemptionId) {
    selectedRedemptionId = redemptionId;
    showModal('upload-proof-modal');
}

function handleProofUpload(event) {
    event.preventDefault();
    
    const fileInput = document.getElementById('proof-file');
    const notes = document.getElementById('proof-notes').value;
    
    if (!fileInput.files[0]) {
        alert('Por favor, selecione um arquivo.');
        return;
    }
    
    // Simular upload
    const redemption = appState.userRedemptions.find(r => r.id === selectedRedemptionId);
    if (redemption) {
        redemption.status = 'proof-uploaded';
        redemption.proofUploaded = true;
        redemption.proofNotes = notes;
        redemption.proofUploadedAt = new Date().toISOString();
    }
    
    closeModal('upload-proof-modal');
    loadUserRedemptions();
    
    // Mostrar confirmação
    alert('Comprovante enviado com sucesso! O fornecedor será notificado para confirmação.');
}

function loadUserProfile() {
    const profileInfo = document.getElementById('profile-info');
    if (!profileInfo) return;
    
    const user = appState.currentUser;
    
    profileInfo.innerHTML = `
        <div class="profile-field">
            <label>Nome:</label>
            <span>${user.name}</span>
        </div>
        <div class="profile-field">
            <label>E-mail:</label>
            <span>${user.email}</span>
        </div>
        <div class="profile-field">
            <label>Tipo de Conta:</label>
            <span>${user.type === 'bni' ? 'Membro BNI' : 'Comunidade'}</span>
        </div>
        ${user.type === 'bni' ? `
            <div class="profile-field">
                <label>Status BNI:</label>
                <span class="status-badge status-approved">Ativo</span>
            </div>
            <div class="profile-field">
                <label>Semáforo:</label>
                <span>${user.semaforo}</span>
            </div>
        ` : `
            <div class="profile-field">
                <label>Padrinho:</label>
                <span>${user.sponsor}</span>
            </div>
        `}
    `;
    
    // Atualizar estatísticas
    updateProfileStats();
}

function updateProfileStats() {
    const totalRedemptions = appState.userRedemptions ? appState.userRedemptions.length : 0;
    const monthlyRedemptions = getUserMonthlyRedemptions();
    
    document.getElementById('total-redemptions').textContent = totalRedemptions;
    document.getElementById('monthly-limit').textContent = `${monthlyRedemptions}/2`;
    
    // Calcular economia total (simulado)
    const totalSavings = appState.userRedemptions ? 
        appState.userRedemptions.reduce((sum, r) => sum + 150, 0) : 0; // Valor simulado
    document.getElementById('savings-total').textContent = formatCurrency(totalSavings);
}

function getUserMonthlyRedemptions() {
    if (!appState.userRedemptions) return 0;
    
    const currentMonth = new Date().getMonth();
    const currentYear = new Date().getFullYear();
    
    return appState.userRedemptions.filter(r => {
        const redemptionDate = new Date(r.redeemedAt);
        return redemptionDate.getMonth() === currentMonth && 
               redemptionDate.getFullYear() === currentYear;
    }).length;
}

function updateRedemptionCounter() {
    const counterEl = document.getElementById('monthly-redemptions');
    if (counterEl) {
        const monthlyCount = getUserMonthlyRedemptions();
        counterEl.textContent = `${monthlyCount}/2`;
        
        if (monthlyCount >= 2) {
            counterEl.classList.add('limit-reached');
        } else {
            counterEl.classList.remove('limit-reached');
        }
    }
}

function logout() {
    appState.currentUser = null;
    appState.userRedemptions = [];
    
    // Remover dashboards do DOM
    const dashboards = document.querySelectorAll('#consumer-dashboard, #provider-dashboard, #admin-dashboard');
    dashboards.forEach(dashboard => dashboard.remove());
    
    // Voltar para landing page
    showPage('landing-page');
}