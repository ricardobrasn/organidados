// Funções específicas do dashboard do administrador

let selectedOfferForApproval = null;
let selectedDisputeForResolution = null;

// Estado administrativo
const adminState = {
    pendingOffers: [
        {
            id: 2,
            title: 'Consultoria Contábil - 40% OFF',
            provider: 'Maria Santos',
            category: 'Contabilidade',
            originalPrice: 500,
            discountPercent: 40,
            finalPrice: 300,
            description: 'Consultoria contábil completa para pequenas empresas',
            terms: 'Válido para primeira consulta. Inclui análise fiscal básica.',
            contactInfo: 'WhatsApp: (11) 88888-8888',
            validUntil: '2026-04-30',
            status: 'pending',
            submittedAt: '2026-02-03'
        }
    ],
    disputes: [
        {
            id: 1,
            redemptionId: 1,
            offerTitle: 'Consultoria Jurídica - 50% OFF',
            provider: 'João Silva',
            customer: 'Pedro Costa',
            reason: 'not-used',
            details: 'Cliente não compareceu à consulta agendada',
            status: 'pending',
            disputedAt: '2026-02-04'
        }
    ],
    recentActivity: [
        { type: 'offer-submitted', message: 'Nova oferta enviada por Maria Santos', time: '2 horas atrás' },
        { type: 'redemption', message: 'Resgate confirmado: Consultoria Jurídica', time: '4 horas atrás' },
        { type: 'member-joined', message: 'Novo membro: Pedro Costa', time: '1 dia atrás' },
        { type: 'dispute', message: 'Nova disputa registrada', time: '2 dias atrás' }
    ]
};

function showAdminDashboard() {
    // Simular usuário admin
    appState.currentUser = {
        email: 'admin@bclub.com',
        name: 'Administrador',
        type: 'admin'
    };
    
    // Carregar o HTML do dashboard do admin
    fetch('admin-dashboard.html')
        .then(response => response.text())
        .then(html => {
            document.body.insertAdjacentHTML('beforeend', html);
            initializeAdminDashboard();
        });
}

function initializeAdminDashboard() {
    showPage('admin-dashboard');
    updateAdminWelcome();
    showAdminSection('overview');
}

function updateAdminWelcome() {
    const welcomeEl = document.getElementById('admin-welcome');
    if (welcomeEl) {
        welcomeEl.textContent = `Olá, ${appState.currentUser.name}`;
    }
}

function showAdminSection(sectionId) {
    // Remover classe active de todas as seções
    document.querySelectorAll('.section').forEach(section => {
        section.classList.remove('active');
    });
    
    // Remover classe active de todos os links da sidebar
    document.querySelectorAll('.sidebar-nav a').forEach(link => {
        link.classList.remove('active');
    });
    
    // Ativar seção correspondente
    const targetSection = document.getElementById(`${sectionId}-section`);
    if (targetSection) {
        targetSection.classList.add('active');
    }
    
    // Ativar link correspondente na sidebar
    const targetLink = document.querySelector(`[onclick="showAdminSection('${sectionId}')"]`);
    if (targetLink) {
        targetLink.classList.add('active');
    }
    
    // Carregar dados específicos da seção
    if (sectionId === 'overview') {
        loadOverviewData();
    } else if (sectionId === 'offer-approval') {
        loadOffersForApproval();
    } else if (sectionId === 'invite-management') {
        loadInviteManagement();
    } else if (sectionId === 'dispute-resolution') {
        loadDisputeResolution();
    }
}

function loadOverviewData() {
    // Atualizar estatísticas
    document.getElementById('total-members').textContent = '24';
    document.getElementById('active-offers-admin').textContent = '12';
    document.getElementById('pending-approvals').textContent = adminState.pendingOffers.length;
    document.getElementById('total-redemptions-admin').textContent = '47';
    
    // Carregar atividade recente
    loadRecentActivity();
    loadPendingActions();
}

function loadRecentActivity() {
    const activityList = document.getElementById('recent-activity');
    if (!activityList) return;
    
    const activityHtml = adminState.recentActivity.map(activity => `
        <div class="activity-item">
            <div class="activity-icon ${activity.type}">
                <i class="fas ${getActivityIcon(activity.type)}"></i>
            </div>
            <div class="activity-content">
                <p>${activity.message}</p>
                <small>${activity.time}</small>
            </div>
        </div>
    `).join('');
    
    activityList.innerHTML = activityHtml;
}

function getActivityIcon(type) {
    const iconMap = {
        'offer-submitted': 'fa-store',
        'redemption': 'fa-ticket-alt',
        'member-joined': 'fa-user-plus',
        'dispute': 'fa-exclamation-triangle'
    };
    return iconMap[type] || 'fa-info-circle';
}

function loadPendingActions() {
    const pendingActions = document.getElementById('pending-actions');
    if (!pendingActions) return;
    
    const actions = [];
    
    if (adminState.pendingOffers.length > 0) {
        actions.push({
            type: 'offers',
            message: `${adminState.pendingOffers.length} oferta(s) aguardando aprovação`,
            action: () => showAdminSection('offer-approval')
        });
    }
    
    if (adminState.disputes.length > 0) {
        actions.push({
            type: 'disputes',
            message: `${adminState.disputes.length} disputa(s) para resolver`,
            action: () => showAdminSection('dispute-resolution')
        });
    }
    
    if (actions.length === 0) {
        pendingActions.innerHTML = `
            <div class="no-pending-actions">
                <i class="fas fa-check-circle"></i>
                <p>Nenhuma ação pendente</p>
            </div>
        `;
        return;
    }
    
    const actionsHtml = actions.map(action => `
        <div class="pending-action-item" onclick="action.action()">
            <div class="action-content">
                <p>${action.message}</p>
            </div>
            <div class="action-arrow">
                <i class="fas fa-chevron-right"></i>
            </div>
        </div>
    `).join('');
    
    pendingActions.innerHTML = actionsHtml;
}

function loadOffersForApproval() {
    const offersList = document.getElementById('offers-approval-list');
    if (!offersList) return;
    
    if (adminState.pendingOffers.length === 0) {
        offersList.innerHTML = `
            <div class="empty-state">
                <i class="fas fa-clipboard-check"></i>
                <h3>Nenhuma oferta pendente</h3>
                <p>Todas as ofertas foram analisadas!</p>
            </div>
        `;
        return;
    }
    
    const offersHtml = adminState.pendingOffers.map(offer => `
        <div class="approval-offer-card">
            <div class="offer-header">
                <h3>${offer.title}</h3>
                <span class="status-badge status-warning">Pendente</span>
            </div>
            
            <div class="offer-details">
                <div class="detail-row">
                    <span class="label">Fornecedor:</span>
                    <span>${offer.provider}</span>
                </div>
                <div class="detail-row">
                    <span class="label">Categoria:</span>
                    <span>${offer.category}</span>
                </div>
                <div class="detail-row">
                    <span class="label">Preço:</span>
                    <span>${formatCurrency(offer.finalPrice)} (${offer.discountPercent}% OFF)</span>
                </div>
                <div class="detail-row">
                    <span class="label">Enviado em:</span>
                    <span>${formatDate(offer.submittedAt)}</span>
                </div>
            </div>
            
            <div class="offer-actions">
                <button class="btn btn-outline btn-sm" onclick="showOfferApprovalModal(${offer.id})">
                    <i class="fas fa-eye"></i> Analisar
                </button>
                <button class="btn btn-success btn-sm" onclick="quickApproveOffer(${offer.id})">
                    <i class="fas fa-check"></i> Aprovar
                </button>
                <button class="btn btn-danger btn-sm" onclick="quickRejectOffer(${offer.id})">
                    <i class="fas fa-times"></i> Rejeitar
                </button>
            </div>
        </div>
    `).join('');
    
    offersList.innerHTML = offersHtml;
}

function showOfferApprovalModal(offerId) {
    const offer = adminState.pendingOffers.find(o => o.id === offerId);
    if (!offer) return;
    
    selectedOfferForApproval = offerId;
    
    const contentEl = document.getElementById('offer-approval-content');
    contentEl.innerHTML = `
        <div class="offer-approval-details">
            <div class="offer-info-grid">
                <div class="offer-main-details">
                    <h4>${offer.title}</h4>
                    <div class="detail-row">
                        <span class="label">Fornecedor:</span>
                        <span>${offer.provider}</span>
                    </div>
                    <div class="detail-row">
                        <span class="label">Categoria:</span>
                        <span>${offer.category}</span>
                    </div>
                    <div class="detail-row">
                        <span class="label">Preço Original:</span>
                        <span>${formatCurrency(offer.originalPrice)}</span>
                    </div>
                    <div class="detail-row">
                        <span class="label">Desconto:</span>
                        <span>${offer.discountPercent}%</span>
                    </div>
                    <div class="detail-row">
                        <span class="label">Preço Final:</span>
                        <span class="final-price">${formatCurrency(offer.finalPrice)}</span>
                    </div>
                    <div class="detail-row">
                        <span class="label">Válido até:</span>
                        <span>${formatDate(offer.validUntil)}</span>
                    </div>
                </div>
                
                <div class="offer-content-details">
                    <div class="content-section">
                        <h5>Descrição</h5>
                        <p>${offer.description}</p>
                    </div>
                    
                    <div class="content-section">
                        <h5>Termos e Condições</h5>
                        <p>${offer.terms}</p>
                    </div>
                    
                    <div class="content-section">
                        <h5>Informações de Contato</h5>
                        <p>${offer.contactInfo}</p>
                    </div>
                </div>
            </div>
            
            <div class="approval-checklist">
                <h5>Checklist de Aprovação</h5>
                <div class="checklist-items">
                    <label class="checklist-item">
                        <input type="checkbox" id="check-clear-description">
                        <span>Descrição clara e objetiva</span>
                    </label>
                    <label class="checklist-item">
                        <input type="checkbox" id="check-fair-discount">
                        <span>Desconto justo e atrativo</span>
                    </label>
                    <label class="checklist-item">
                        <input type="checkbox" id="check-clear-terms">
                        <span>Termos e condições claros</span>
                    </label>
                    <label class="checklist-item">
                        <input type="checkbox" id="check-contact-info">
                        <span>Informações de contato adequadas</span>
                    </label>
                    <label class="checklist-item">
                        <input type="checkbox" id="check-valid-period">
                        <span>Período de validade adequado</span>
                    </label>
                </div>
            </div>
        </div>
        
        <div class="approval-actions">
            <div class="rejection-section">
                <textarea id="rejection-reason" placeholder="Motivo da rejeição (obrigatório para rejeitar)" rows="3"></textarea>
            </div>
            <div class="action-buttons">
                <button class="btn btn-outline" onclick="closeModal('offer-approval-modal')">
                    Cancelar
                </button>
                <button class="btn btn-danger" onclick="rejectOfferWithReason()">
                    <i class="fas fa-times"></i> Rejeitar
                </button>
                <button class="btn btn-success" onclick="approveOffer()">
                    <i class="fas fa-check"></i> Aprovar
                </button>
            </div>
        </div>
    `;
    
    showModal('offer-approval-modal');
}

function approveOffer() {
    const offer = adminState.pendingOffers.find(o => o.id === selectedOfferForApproval);
    if (offer) {
        offer.status = 'approved';
        offer.approvedAt = new Date().toISOString();
        
        // Remover da lista de pendentes
        adminState.pendingOffers = adminState.pendingOffers.filter(o => o.id !== selectedOfferForApproval);
        
        // Adicionar às ofertas ativas
        appState.offers.push({
            ...offer,
            image: 'https://via.placeholder.com/300x200?text=' + encodeURIComponent(offer.category)
        });
    }
    
    closeModal('offer-approval-modal');
    loadOffersForApproval();
    loadOverviewData();
    
    alert('Oferta aprovada com sucesso!');
}

function rejectOfferWithReason() {
    const reason = document.getElementById('rejection-reason').value.trim();
    if (!reason) {
        alert('Por favor, informe o motivo da rejeição.');
        return;
    }
    
    const offer = adminState.pendingOffers.find(o => o.id === selectedOfferForApproval);
    if (offer) {
        offer.status = 'rejected';
        offer.rejectedAt = new Date().toISOString();
        offer.rejectionReason = reason;
        
        // Remover da lista de pendentes
        adminState.pendingOffers = adminState.pendingOffers.filter(o => o.id !== selectedOfferForApproval);
    }
    
    closeModal('offer-approval-modal');
    loadOffersForApproval();
    loadOverviewData();
    
    alert('Oferta rejeitada. O fornecedor será notificado.');
}

function quickApproveOffer(offerId) {
    if (confirm('Tem certeza que deseja aprovar esta oferta?')) {
        selectedOfferForApproval = offerId;
        approveOffer();
    }
}

function quickRejectOffer(offerId) {
    const reason = prompt('Informe o motivo da rejeição:');
    if (reason && reason.trim()) {
        selectedOfferForApproval = offerId;
        document.body.insertAdjacentHTML('beforeend', `<textarea id="rejection-reason" style="display:none">${reason}</textarea>`);
        rejectOfferWithReason();
        document.getElementById('rejection-reason').remove();
    }
}

function loadInviteManagement() {
    const invitesList = document.getElementById('invites-list');
    if (!invitesList) return;
    
    const invitesHtml = Object.entries(appState.inviteCodes).map(([code, data]) => `
        <div class="invite-card">
            <div class="invite-header">
                <h3 class="invite-code">${code}</h3>
                <span class="usage-badge ${data.uses >= data.maxUses ? 'exhausted' : 'active'}">
                    ${data.uses}/${data.maxUses} usos
                </span>
            </div>
            
            <div class="invite-details">
                <div class="detail-row">
                    <span class="label">Padrinho:</span>
                    <span>${data.sponsor}</span>
                </div>
                <div class="detail-row">
                    <span class="label">Status:</span>
                    <span class="${data.uses >= data.maxUses ? 'exhausted' : 'active'}">
                        ${data.uses >= data.maxUses ? 'Esgotado' : 'Ativo'}
                    </span>
                </div>
            </div>
            
            <div class="invite-actions">
                <button class="btn btn-outline btn-sm" onclick="editInvite('${code}')">
                    <i class="fas fa-edit"></i> Editar
                </button>
                <button class="btn btn-danger btn-sm" onclick="deactivateInvite('${code}')">
                    <i class="fas fa-ban"></i> Desativar
                </button>
            </div>
        </div>
    `).join('');
    
    invitesList.innerHTML = invitesHtml;
}

function showCreateInviteModal() {
    showModal('create-invite-modal');
}

function handleCreateInvite(event) {
    event.preventDefault();
    
    const code = document.getElementById('invite-code-input').value.toUpperCase();
    const sponsor = document.getElementById('invite-sponsor').value;
    const maxUses = parseInt(document.getElementById('invite-max-uses').value);
    const notes = document.getElementById('invite-notes').value;
    
    if (appState.inviteCodes[code]) {
        alert('Este código já existe. Escolha outro código.');
        return;
    }
    
    appState.inviteCodes[code] = {
        uses: 0,
        maxUses: maxUses,
        sponsor: sponsor,
        notes: notes,
        createdAt: new Date().toISOString()
    };
    
    closeModal('create-invite-modal');
    loadInviteManagement();
    
    // Limpar formulário
    document.getElementById('invite-code-input').value = '';
    document.getElementById('invite-sponsor').value = '';
    document.getElementById('invite-max-uses').value = '3';
    document.getElementById('invite-notes').value = '';
    
    alert('Código de convite criado com sucesso!');
}

function loadDisputeResolution() {
    const disputesList = document.getElementById('disputes-list');
    if (!disputesList) return;
    
    if (adminState.disputes.length === 0) {
        disputesList.innerHTML = `
            <div class="empty-state">
                <i class="fas fa-gavel"></i>
                <h3>Nenhuma disputa pendente</h3>
                <p>Todas as disputas foram resolvidas!</p>
            </div>
        `;
        return;
    }
    
    const disputesHtml = adminState.disputes.map(dispute => `
        <div class="dispute-card">
            <div class="dispute-header">
                <h3>${dispute.offerTitle}</h3>
                <span class="status-badge status-warning">Pendente</span>
            </div>
            
            <div class="dispute-details">
                <div class="detail-row">
                    <span class="label">Fornecedor:</span>
                    <span>${dispute.provider}</span>
                </div>
                <div class="detail-row">
                    <span class="label">Cliente:</span>
                    <span>${dispute.customer}</span>
                </div>
                <div class="detail-row">
                    <span class="label">Motivo:</span>
                    <span>${getDisputeReasonText(dispute.reason)}</span>
                </div>
                <div class="detail-row">
                    <span class="label">Data:</span>
                    <span>${formatDate(dispute.disputedAt)}</span>
                </div>
            </div>
            
            <div class="dispute-description">
                <p><strong>Detalhes:</strong> ${dispute.details}</p>
            </div>
            
            <div class="dispute-actions">
                <button class="btn btn-primary btn-sm" onclick="showResolveDisputeModal(${dispute.id})">
                    <i class="fas fa-gavel"></i> Resolver
                </button>
            </div>
        </div>
    `).join('');
    
    disputesList.innerHTML = disputesHtml;
}

function getDisputeReasonText(reason) {
    const reasonMap = {
        'not-used': 'Benefício não utilizado',
        'invalid-proof': 'Comprovante inválido',
        'terms-violation': 'Violação dos termos',
        'other': 'Outro motivo'
    };
    return reasonMap[reason] || reason;
}

function showResolveDisputeModal(disputeId) {
    const dispute = adminState.disputes.find(d => d.id === disputeId);
    if (!dispute) return;
    
    selectedDisputeForResolution = disputeId;
    
    const contentEl = document.getElementById('dispute-resolution-content');
    contentEl.innerHTML = `
        <div class="dispute-resolution-details">
            <div class="dispute-summary">
                <h4>Resumo da Disputa</h4>
                <div class="summary-grid">
                    <div class="summary-item">
                        <label>Oferta:</label>
                        <span>${dispute.offerTitle}</span>
                    </div>
                    <div class="summary-item">
                        <label>Fornecedor:</label>
                        <span>${dispute.provider}</span>
                    </div>
                    <div class="summary-item">
                        <label>Cliente:</label>
                        <span>${dispute.customer}</span>
                    </div>
                    <div class="summary-item">
                        <label>Motivo:</label>
                        <span>${getDisputeReasonText(dispute.reason)}</span>
                    </div>
                </div>
                <div class="dispute-details-text">
                    <label>Detalhes da contestação:</label>
                    <p>${dispute.details}</p>
                </div>
            </div>
            
            <div class="resolution-form">
                <h4>Resolução</h4>
                <div class="form-group">
                    <label for="resolution-decision">Decisão *</label>
                    <select id="resolution-decision" required>
                        <option value="">Selecione uma decisão</option>
                        <option value="favor-provider">A favor do fornecedor</option>
                        <option value="favor-customer">A favor do cliente</option>
                        <option value="partial">Resolução parcial</option>
                    </select>
                </div>
                <div class="form-group">
                    <label for="resolution-notes">Justificativa *</label>
                    <textarea id="resolution-notes" rows="4" required 
                              placeholder="Explique a decisão tomada e as ações necessárias..."></textarea>
                </div>
            </div>
        </div>
        
        <div class="modal-actions">
            <button class="btn btn-outline" onclick="closeModal('resolve-dispute-modal')">
                Cancelar
            </button>
            <button class="btn btn-primary" onclick="resolveDispute()">
                <i class="fas fa-gavel"></i> Resolver Disputa
            </button>
        </div>
    `;
    
    showModal('resolve-dispute-modal');
}

function resolveDispute() {
    const decision = document.getElementById('resolution-decision').value;
    const notes = document.getElementById('resolution-notes').value.trim();
    
    if (!decision || !notes) {
        alert('Por favor, preencha todos os campos obrigatórios.');
        return;
    }
    
    const dispute = adminState.disputes.find(d => d.id === selectedDisputeForResolution);
    if (dispute) {
        dispute.status = 'resolved';
        dispute.resolution = decision;
        dispute.resolutionNotes = notes;
        dispute.resolvedAt = new Date().toISOString();
        
        // Remover da lista de disputas pendentes
        adminState.disputes = adminState.disputes.filter(d => d.id !== selectedDisputeForResolution);
    }
    
    closeModal('resolve-dispute-modal');
    loadDisputeResolution();
    loadOverviewData();
    
    alert('Disputa resolvida com sucesso! As partes serão notificadas.');
}

function editInvite(code) {
    alert('Funcionalidade de edição será implementada em breve.');
}

function deactivateInvite(code) {
    if (confirm(`Tem certeza que deseja desativar o código ${code}?`)) {
        delete appState.inviteCodes[code];
        loadInviteManagement();
        alert('Código desativado com sucesso.');
    }
}