# BClub - Protótipo Web Navegável

## 📋 Sobre o Projeto

O BClub é um protótipo de clube de benefícios exclusivo para o Capítulo Piloto BNI, desenvolvido como MVP visual navegável. O sistema permite que membros BNI e comunidade convidada acessem ofertas especiais com total rastreabilidade e curadoria rigorosa.

## 🎯 Funcionalidades Implementadas

### 🏠 Landing Page
- Apresentação do conceito BClub
- Explicação do funcionamento
- Opções de adesão (BNI e Comunidade)
- Botões de demonstração dos dashboards

### 👤 Sistema de Usuários

#### **Consumidor BNI**
- Validação de elegibilidade (semáforo ≥ 70, sem dívidas)
- Limite de 2 resgates por mês
- Catálogo de ofertas com filtros
- Sistema de resgate com código único
- Upload de comprovantes
- Acompanhamento de status

#### **Consumidor Comunidade**
- Adesão via código de convite
- Mesmo limite de resgates
- Funcionalidades idênticas ao BNI

#### **Fornecedor (Membro BNI)**
- Criação e gestão de ofertas
- Aprovação/rejeição de resgates
- Sistema de contestação
- Dashboard com estatísticas

#### **Administrador**
- Curadoria de ofertas
- Gestão de códigos de convite
- Resolução de disputas
- Relatórios do piloto
- Configurações do sistema

## 🚀 Como Usar

### Acesso Rápido aos Dashboards
Na landing page, use os botões de demonstração:
- **Dashboard Consumidor**: Experiência completa de navegação e resgate
- **Dashboard Fornecedor**: Gestão de ofertas e confirmação de resgates
- **Dashboard Admin**: Curadoria e administração do sistema

### Fluxos de Teste

#### **Adesão BNI**
1. Clique em "Aderir" → "Sou Membro BNI"
2. Use emails de teste:
   - `joao@empresa.com` (elegível)
   - `maria@marketing.com` (elegível)
   - `pedro@consultoria.com` (não elegível - tem dívidas)

#### **Adesão Comunidade**
1. Clique em "Aderir" → "Tenho Código de Convite"
2. Use códigos de teste:
   - `PILOT2026` (2/3 usos)
   - `BCLUB001` (1/3 usos)

#### **Resgate de Benefícios**
1. Navegue pelo catálogo
2. Clique em "Ver Detalhes" em uma oferta
3. Clique em "Resgatar Benefício"
4. Confirme o resgate
5. Receba código único
6. Envie comprovante posteriormente

## 🎨 Design e UX

### Identidade Visual
- Cores profissionais inspiradas no BNI
- Interface limpa e confiável
- Status sempre visíveis com badges coloridos
- Linguagem clara e objetiva

### Responsividade
- Layout adaptável para desktop e mobile
- Navegação otimizada para diferentes dispositivos
- Componentes flexíveis

## 🔧 Tecnologias Utilizadas

- **HTML5**: Estrutura semântica
- **CSS3**: Estilização moderna com CSS Grid e Flexbox
- **JavaScript**: Interatividade e simulação de estados
- **Font Awesome**: Ícones
- **Google Fonts**: Tipografia (Inter)

## 📁 Estrutura de Arquivos

```
bclub-prototype/
├── index.html              # Página principal
├── styles.css              # Estilos globais
├── app.js                  # Lógica principal
├── consumer-functions.js   # Funções do consumidor
├── provider-functions.js   # Funções do fornecedor
├── admin-functions.js      # Funções do administrador
├── consumer-dashboard.html # Template do dashboard consumidor
├── provider-dashboard.html # Template do dashboard fornecedor
├── admin-dashboard.html    # Template do dashboard admin
└── README.md              # Este arquivo
```

## 🎭 Estados Simulados

### Ofertas
- Aprovadas e disponíveis no catálogo
- Pendentes de aprovação (admin)
- Rejeitadas com motivos

### Resgates
- Resgatado (aguardando comprovante)
- Comprovante enviado (aguardando confirmação)
- Confirmado pelo fornecedor
- Contestado (em disputa)

### Usuários
- Membros BNI elegíveis/não elegíveis
- Comunidade com códigos válidos
- Fornecedores ativos
- Administradores

## 🔐 Regras de Negócio Implementadas

### Elegibilidade BNI
- Status: membro ativo
- Semáforo: ≥ 70 pontos
- Situação financeira: sem pendências

### Limites e Controles
- 2 resgates por usuário/mês
- 3 usos por código de convite
- Prazo de 7 dias para comprovante
- Curadoria obrigatória de ofertas

### Rastreabilidade
- Códigos únicos de resgate
- Histórico completo de transações
- Status em tempo real
- Confirmação dupla (consumidor + fornecedor)

## 🎯 Próximos Passos (Fora do Escopo)

- Integração com API BNI real
- Sistema de notificações
- Gateway de pagamento
- App mobile nativo
- Analytics avançados
- Sistema de avaliações

## 📞 Suporte

Este é um protótipo para validação com usuários do capítulo piloto. Para dúvidas sobre implementação real, consulte a documentação técnica completa.

---

**BClub** - Clube de Benefícios Exclusivo do Capítulo Piloto BNI