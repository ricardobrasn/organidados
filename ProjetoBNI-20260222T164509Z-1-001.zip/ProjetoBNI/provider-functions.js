// Funções específicas do dashboard do fornecedor

let selectedRedemptionForAction = null;

// Estado das ofertas do fornecedor
const providerState = {
    offers: [
        {
            id: 1,
            title: 'Consultoria Jurídica - 50% OFF',
            category: 'Jurídico',
            originalPrice: 300,
            discountPercent: 50,
            finalPrice: 150,
            description: 'Consultoria jurídica especializada em direito empresarial',
            terms: 'Válido para primeira consulta. Agendamento obrigatório.',
            contactInfo: 'WhatsApp: (11) 99999-9999 ou email: contato@juridico.com',
            validUntil: '2026-03-31',
            maxRedemptions: null,
            status: 'approved',
            createdAt: '2026-01-15',
            redemptions: 5
        }
    ],
    redemptions: [
        {
            id: 1,
            offerId: 1,
            offerTitle: 'Consultoria Jurídica - 50% OFF',
            customerName: 'João Silva',
            customerEmail: 'joao@empresa.com',
            redemptionCode: 'BC123456',
            redeemedAt: '2026-02-01',
            status: 'proof-uploaded',
            proofUploaded: true,
            proofUploadedAt: '2026-02-03',
            proofNotes: 'Consulta realizada em 02/02/2026'
        }
    ]
};

function showProviderDashboard() {
    // Simular usuário fornecedor
    appState.currentUser = {
        email: 'fornecedor@empresa.com',
        name: 'João Silva',
        type: 'provider'
    };
    
    // Carregar o HTML do dashboard do fornecedor
    fetch('provider-dashboard.html')
        .then(response => response.text())
        .then(html => {
            document.body.insertAdjacentHTML('beforeend', html);
            initializeProviderDashboard();
        });
}

function initializeProviderDashboard() {
    showPage('provider-dashboard');
    updateProviderWelcome();
    showProviderSection('my-offers');
}

function updateProviderWelcome() {
    const welcomeEl = document.getElementById('provider-welcome');
    if (welcomeEl) {
        welcomeEl.textContent = `Olá, ${appState.currentUser.name}`;
    }
}

function showProviderSection(sectionId) {
    // Remover classe active de todas as seções
    document.querySelectorAll('.section').forEach(section => {
        section.classList.remove('active');
    });
    
    // Remover classe active de todos os links da sidebar
    document.querySelectorAll('.sidebar-nav a').forEach(link => {
        link.classList.remove('active');
    });
    
    // Ativar seção correspondente
    const targetSection = document.getElementById(`${sectionId}-section`);
    if (targetSection) {
        targetSection.classList.add('active');
    }
    
    // Ativar link correspondente na sidebar
    const targetLink = document.querySelector(`[onclick="showProviderSection('${sectionId}')"]`);
    if (targetLink) {
        targetLink.classList.add('active');
    }
    
    // Carregar dados específicos da seção
    if (sectionId === 'my-offers') {
        loadProviderOffers();
        updateOffersStats();
    } else if (sectionId === 'create-offer') {
        resetOfferForm();
        setMinDate();
    } else if (sectionId === 'redemptions') {
        loadProviderRedemptions();
    } else if (sectionId === 'profile') {
        loadProviderProfile();
    }
}

function loadProviderOffers() {
    const offersList = document.getElementById('provider-offers-list');
    if (!offersList) return;
    
    if (providerState.offers.length === 0) {
        offersList.innerHTML = `
            <div class="empty-state">
                <i class="fas fa-store"></i>
                <h3>Nenhuma oferta criada</h3>
                <p>Crie sua primeira oferta para começar a vender no BClub!</p>
                <button class="btn btn-primary" onclick="showProviderSection('create-offer')">
                    Criar Primeira Oferta
                </button>
            </div>
        `;
        return;
    }
    
    const offersHtml = providerState.offers.map(offer => `
        <div class="provider-offer-card">
            <div class="offer-header">
                <h3>${offer.title}</h3>
                <span class="status-badge ${getOfferStatusClass(offer.status)}">
                    ${getOfferStatusText(offer.status)}
                </span>
            </div>
            
            <div class="offer-details">
                <div class="detail-row">
                    <span class="label">Categoria:</span>
                    <span>${offer.category}</span>
                </div>
                <div class="detail-row">
                    <span class="label">Preço:</span>
                    <span>${formatCurrency(offer.finalPrice)} (${offer.discountPercent}% OFF)</span>
                </div>
                <div class="detail-row">
                    <span class="label">Válido até:</span>
                    <span>${formatDate(offer.validUntil)}</span>
                </div>
                <div class="detail-row">
                    <span class="label">Resgates:</span>
                    <span>${offer.redemptions} ${offer.maxRedemptions ? `/ ${offer.maxRedemptions}` : ''}</span>
                </div>
            </div>
            
            <div class="offer-actions">
                <button class="btn btn-outline btn-sm" onclick="editOffer(${offer.id})">
                    <i class="fas fa-edit"></i> Editar
                </button>
                ${offer.status === 'approved' ? `
                    <button class="btn btn-warning btn-sm" onclick="pauseOffer(${offer.id})">
                        <i class="fas fa-pause"></i> Pausar
                    </button>
                ` : ''}
                ${offer.status === 'paused' ? `
                    <button class="btn btn-success btn-sm" onclick="activateOffer(${offer.id})">
                        <i class="fas fa-play"></i> Ativar
                    </button>
                ` : ''}
            </div>
        </div>
    `).join('');
    
    offersList.innerHTML = offersHtml;
}

function getOfferStatusClass(status) {
    const statusMap = {
        'draft': 'status-pending',
        'pending': 'status-warning',
        'approved': 'status-approved',
        'rejected': 'status-rejected',
        'paused': 'status-warning',
        'expired': 'status-rejected'
    };
    return statusMap[status] || 'status-pending';
}

function getOfferStatusText(status) {
    const statusMap = {
        'draft': 'Rascunho',
        'pending': 'Em Análise',
        'approved': 'Aprovada',
        'rejected': 'Rejeitada',
        'paused': 'Pausada',
        'expired': 'Expirada'
    };
    return statusMap[status] || 'Pendente';
}

function updateOffersStats() {
    const totalOffers = providerState.offers.length;
    const activeOffers = providerState.offers.filter(o => o.status === 'approved').length;
    const totalRedemptions = providerState.offers.reduce((sum, o) => sum + o.redemptions, 0);
    
    document.getElementById('total-offers').textContent = totalOffers;
    document.getElementById('active-offers').textContent = activeOffers;
    document.getElementById('total-redemptions-provider').textContent = totalRedemptions;
}

function setMinDate() {
    const today = new Date();
    const tomorrow = new Date(today);
    tomorrow.setDate(tomorrow.getDate() + 1);
    
    const validUntilInput = document.getElementById('valid-until');
    if (validUntilInput) {
        validUntilInput.min = tomorrow.toISOString().split('T')[0];
    }
}

function handleCreateOffer(event) {
    event.preventDefault();
    
    const formData = {
        title: document.getElementById('offer-title').value,
        category: document.getElementById('offer-category').value,
        originalPrice: parseFloat(document.getElementById('original-price').value),
        discountPercent: parseInt(document.getElementById('discount-percent').value),
        validUntil: document.getElementById('valid-until').value,
        maxRedemptions: document.getElementById('max-redemptions').value || null,
        description: document.getElementById('offer-description').value,
        terms: document.getElementById('offer-terms').value,
        contactInfo: document.getElementById('contact-info').value
    };
    
    // Calcular preço final
    formData.finalPrice = formData.originalPrice * (1 - formData.discountPercent / 100);
    
    // Criar nova oferta
    const newOffer = {
        id: Date.now(),
        ...formData,
        status: 'pending',
        createdAt: new Date().toISOString(),
        redemptions: 0
    };
    
    providerState.offers.push(newOffer);
    
    // Mostrar confirmação
    showOfferSubmissionSuccess();
    
    // Limpar formulário
    resetOfferForm();
    
    // Voltar para lista de ofertas
    showProviderSection('my-offers');
}

function showOfferSubmissionSuccess() {
    const successHtml = `
        <div class="modal active" id="offer-submission-success">
            <div class="modal-content">
                <div class="modal-header">
                    <h2>✅ Oferta Enviada com Sucesso!</h2>
                </div>
                <div class="success-content">
                    <div class="success-message">
                        <i class="fas fa-paper-plane"></i>
                        <h3>Sua oferta foi enviada para análise</h3>
                        <p>Nossa equipe de curadoria irá revisar sua oferta e você receberá uma notificação em até 48 horas.</p>
                    </div>
                    
                    <div class="next-steps">
                        <h4>Próximos Passos:</h4>
                        <ol>
                            <li>Aguarde a análise da equipe de curadoria</li>
                            <li>Você receberá um e-mail com o resultado</li>
                            <li>Se aprovada, sua oferta ficará disponível no catálogo</li>
                        </ol>
                    </div>
                    
                    <button class="btn btn-primary" onclick="closeModal('offer-submission-success')">
                        Entendi
                    </button>
                </div>
            </div>
        </div>
    `;
    
    document.body.insertAdjacentHTML('beforeend', successHtml);
}

function resetOfferForm() {
    const form = document.getElementById('create-offer-form');
    if (form) {
        form.reset();
    }
}

function loadProviderRedemptions() {
    const redemptionsList = document.getElementById('provider-redemptions-list');
    if (!redemptionsList) return;
    
    if (providerState.redemptions.length === 0) {
        redemptionsList.innerHTML = `
            <div class="empty-state">
                <i class="fas fa-ticket-alt"></i>
                <h3>Nenhum resgate recebido</h3>
                <p>Quando alguém resgatar suas ofertas, elas aparecerão aqui.</p>
            </div>
        `;
        return;
    }
    
    const redemptionsHtml = providerState.redemptions.map(redemption => `
        <div class="provider-redemption-card">
            <div class="redemption-header">
                <h3>${redemption.offerTitle}</h3>
                <span class="status-badge ${getStatusClass(redemption.status)}">
                    ${getStatusText(redemption.status)}
                </span>
            </div>
            
            <div class="redemption-details">
                <div class="detail-row">
                    <span class="label">Cliente:</span>
                    <span>${redemption.customerName}</span>
                </div>
                <div class="detail-row">
                    <span class="label">E-mail:</span>
                    <span>${redemption.customerEmail}</span>
                </div>
                <div class="detail-row">
                    <span class="label">Código:</span>
                    <span class="redemption-code">${redemption.redemptionCode}</span>
                </div>
                <div class="detail-row">
                    <span class="label">Data do Resgate:</span>
                    <span>${formatDate(redemption.redeemedAt)}</span>
                </div>
                ${redemption.proofUploaded ? `
                    <div class="detail-row">
                        <span class="label">Comprovante:</span>
                        <span>${formatDate(redemption.proofUploadedAt)}</span>
                    </div>
                    ${redemption.proofNotes ? `
                        <div class="detail-row">
                            <span class="label">Observações:</span>
                            <span>${redemption.proofNotes}</span>
                        </div>
                    ` : ''}
                ` : ''}
            </div>
            
            <div class="redemption-actions">
                ${getProviderRedemptionActions(redemption)}
            </div>
        </div>
    `).join('');
    
    redemptionsList.innerHTML = redemptionsHtml;
}

function getProviderRedemptionActions(redemption) {
    if (redemption.status === 'proof-uploaded') {
        return `
            <button class="btn btn-success btn-sm" onclick="showConfirmRedemption(${redemption.id})">
                <i class="fas fa-check"></i> Confirmar
            </button>
            <button class="btn btn-danger btn-sm" onclick="showDisputeRedemption(${redemption.id})">
                <i class="fas fa-times"></i> Contestar
            </button>
        `;
    } else if (redemption.status === 'confirmed') {
        return `
            <span class="status-info success">
                <i class="fas fa-check-circle"></i>
                Confirmado
            </span>
        `;
    } else if (redemption.status === 'disputed') {
        return `
            <span class="status-info danger">
                <i class="fas fa-exclamation-triangle"></i>
                Contestado
            </span>
        `;
    }
    
    return `
        <span class="status-info">
            <i class="fas fa-clock"></i>
            Aguardando comprovante
        </span>
    `;
}

function showConfirmRedemption(redemptionId) {
    const redemption = providerState.redemptions.find(r => r.id === redemptionId);
    if (!redemption) return;
    
    selectedRedemptionForAction = redemptionId;
    
    const contentEl = document.getElementById('redemption-confirmation-content');
    contentEl.innerHTML = `
        <div class="confirmation-details">
            <h4>Confirmar utilização do benefício</h4>
            <div class="redemption-summary">
                <p><strong>Oferta:</strong> ${redemption.offerTitle}</p>
                <p><strong>Cliente:</strong> ${redemption.customerName}</p>
                <p><strong>Código:</strong> ${redemption.redemptionCode}</p>
                <p><strong>Data do Resgate:</strong> ${formatDate(redemption.redeemedAt)}</p>
                ${redemption.proofNotes ? `<p><strong>Observações do Cliente:</strong> ${redemption.proofNotes}</p>` : ''}
            </div>
            
            <div class="confirmation-warning">
                <i class="fas fa-info-circle"></i>
                <p>Ao confirmar, você atesta que o cliente utilizou o benefício conforme os termos estabelecidos.</p>
            </div>
        </div>
        
        <div class="modal-actions">
            <button class="btn btn-outline" onclick="closeModal('confirm-redemption-modal')">
                Cancelar
            </button>
            <button class="btn btn-success" onclick="confirmRedemption()">
                <i class="fas fa-check"></i>
                Confirmar Utilização
            </button>
        </div>
    `;
    
    showModal('confirm-redemption-modal');
}

function confirmRedemption() {
    const redemption = providerState.redemptions.find(r => r.id === selectedRedemptionForAction);
    if (redemption) {
        redemption.status = 'confirmed';
        redemption.confirmedAt = new Date().toISOString();
    }
    
    closeModal('confirm-redemption-modal');
    loadProviderRedemptions();
    
    alert('Resgate confirmado com sucesso!');
}

function showDisputeRedemption(redemptionId) {
    selectedRedemptionForAction = redemptionId;
    showModal('dispute-redemption-modal');
}

function handleDisputeRedemption(event) {
    event.preventDefault();
    
    const reason = document.getElementById('dispute-reason').value;
    const details = document.getElementById('dispute-details').value;
    
    const redemption = providerState.redemptions.find(r => r.id === selectedRedemptionForAction);
    if (redemption) {
        redemption.status = 'disputed';
        redemption.disputeReason = reason;
        redemption.disputeDetails = details;
        redemption.disputedAt = new Date().toISOString();
    }
    
    closeModal('dispute-redemption-modal');
    loadProviderRedemptions();
    
    alert('Contestação registrada. A administração irá analisar o caso.');
    
    // Limpar formulário
    document.getElementById('dispute-reason').value = '';
    document.getElementById('dispute-details').value = '';
}

function loadProviderProfile() {
    const profileInfo = document.getElementById('provider-profile-info');
    if (!profileInfo) return;
    
    const user = appState.currentUser;
    
    profileInfo.innerHTML = `
        <div class="profile-field">
            <label>Nome:</label>
            <span>${user.name}</span>
        </div>
        <div class="profile-field">
            <label>E-mail:</label>
            <span>${user.email}</span>
        </div>
        <div class="profile-field">
            <label>Tipo de Conta:</label>
            <span>Fornecedor BNI</span>
        </div>
        <div class="profile-field">
            <label>Status:</label>
            <span class="status-badge status-approved">Ativo</span>
        </div>
        <div class="profile-field">
            <label>Membro desde:</label>
            <span>Janeiro 2026</span>
        </div>
    `;
    
    // Atualizar estatísticas do fornecedor
    updateProviderStats();
}

function updateProviderStats() {
    const totalOffers = providerState.offers.length;
    const activeOffers = providerState.offers.filter(o => o.status === 'approved').length;
    const totalRedemptions = providerState.offers.reduce((sum, o) => sum + o.redemptions, 0);
    
    document.getElementById('provider-total-offers').textContent = totalOffers;
    document.getElementById('provider-active-offers').textContent = activeOffers;
    document.getElementById('provider-total-redemptions').textContent = totalRedemptions;
}

function editOffer(offerId) {
    alert('Funcionalidade de edição será implementada em breve.');
}

function pauseOffer(offerId) {
    const offer = providerState.offers.find(o => o.id === offerId);
    if (offer) {
        offer.status = 'paused';
        loadProviderOffers();
        updateOffersStats();
    }
}

function activateOffer(offerId) {
    const offer = providerState.offers.find(o => o.id === offerId);
    if (offer) {
        offer.status = 'approved';
        loadProviderOffers();
        updateOffersStats();
    }
}