# 🚗 DEMO - Belcar Investcar

## 🎯 Roteiro de Demonstração

### 1. Acesso Inicial
- Abra `http://localhost:5173`
- Visualize o **Dashboard** com propostas mockadas
- Observe a identidade visual Belcar (azul corporativo)

### 2. Criação de Nova Proposta
- Clique em **"Nova Proposta"**
- Use os botões de exemplo para pré-preencher:
  - **"Exemplo (Dinheiro)"** - João Silva Santos
  - **"Exemplo (Cheque)"** - Maria Oliveira Costa
- Ou preencha manualmente os campos

### 3. Geração da Minuta
- Clique em **"Visualizar Minuta"**
- Observe o contrato gerado automaticamente
- Veja a formatação jurídica profissional
- Dados preenchidos dinamicamente

### 4. Link de Assinatura
- Na tela do contrato, clique **"Enviar para Assinatura"**
- Link único é gerado e copiado
- Formato: `/assinatura/{hash}`

### 5. Processo de Assinatura
- Acesse o link copiado (nova aba/janela)
- Visualize o resumo do contrato
- Desenhe a assinatura no canvas
- Confirme a assinatura digital

### 6. Funcionalidades Extras
- **Simular E-mail**: Modal de confirmação
- **Gerar PDF**: Aviso de funcionalidade futura
- **Navegação**: Voltar, Dashboard, etc.

## 🎨 Pontos de Destaque

### Design Profissional
- ✅ Cores corporativas Belcar
- ✅ Layout limpo e moderno
- ✅ Tipografia Inter (Google Fonts)
- ✅ Responsivo para mobile/desktop

### Experiência do Usuário
- ✅ Fluxo intuitivo e linear
- ✅ Modais informativos
- ✅ Feedback visual claro
- ✅ Botões de exemplo para agilizar testes

### Funcionalidades Técnicas
- ✅ Geração automática de contratos
- ✅ Links únicos com hash
- ✅ Canvas para assinatura digital
- ✅ Persistência local (localStorage)
- ✅ Navegação SPA (Single Page App)

## 📱 Teste em Diferentes Dispositivos

### Desktop
- Layout completo com sidebar
- Formulários em grid 2 colunas
- Visualização otimizada do contrato

### Mobile/Tablet
- Layout responsivo
- Formulários em coluna única
- Canvas de assinatura adaptável

## 🔍 Validações Implementadas

- ✅ Campos obrigatórios
- ✅ Validação de e-mail
- ✅ Formatação de valores monetários
- ✅ Condicionais (campos de cheque)

## 🚀 Próximos Passos (Apresentação)

1. **Demonstrar fluxo completo**
2. **Destacar identidade visual**
3. **Mostrar responsividade**
4. **Explicar arquitetura preparada para backend**
5. **Apresentar roadmap de funcionalidades**

## 💡 Dicas para Demonstração

- Use os **botões de exemplo** para agilizar
- Teste o **canvas de assinatura** desenhando
- Mostre a **geração automática** do contrato
- Destaque a **identidade visual** Belcar
- Explique que é **frontend-only** (protótipo)

---

**🎯 Objetivo**: Validar visualmente o fluxo e apresentar para a diretoria da Belcar Investcar