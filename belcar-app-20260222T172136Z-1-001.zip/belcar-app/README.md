# Belcar Investcar - Protótipo de Sistema de Financiamento

## 🚗 Sobre o Projeto

Protótipo navegável de um sistema web para a Belcar Investcar, focado em:
- Preenchimento de formulário de proposta
- Geração automática da minuta de contrato
- Simulação de envio por e-mail
- Geração de link único com hash para assinatura
- Assinatura digital simulada

## 🎨 Identidade Visual

- **Cores principais**: Azul Belcar (#1e40af), Azul escuro (#1e3a8a)
- **Tipografia**: Inter (Google Fonts)
- **Layout**: Corporativo, limpo, estilo concessionária
- **Objetivo**: Transmitir segurança, formalidade e credibilidade

## 🚀 Como Executar

1. **Instalar dependências:**
   ```bash
   npm install
   ```

2. **Executar em modo desenvolvimento:**
   ```bash
   npm run dev
   ```

3. **Acessar a aplicação:**
   - Abra o navegador em `http://localhost:5173`

## 📱 Funcionalidades

### 1. Dashboard
- Visualização de propostas mockadas
- Estatísticas básicas
- Botão para criar nova proposta

### 2. Formulário de Proposta
- **Dados do Comprador**: Nome, CPF/CNPJ, endereço, contatos
- **Condições da Venda**: Modelo, valor, parcelas, entrada
- **Recibo**: Valor recebido, forma de pagamento
- **Ações**: Visualizar minuta, gerar link, simular e-mail

### 3. Visualização do Contrato
- Minuta gerada automaticamente com dados do formulário
- Layout profissional com cabeçalho Belcar
- Cláusulas contratuais formatadas
- Botões para PDF e envio para assinatura

### 4. Página de Assinatura
- Acesso via link único com hash
- Visualização resumida do contrato
- Canvas para assinatura digital
- Confirmação de aceite

## 🔧 Tecnologias Utilizadas

- **React 18** - Framework principal
- **React Router DOM** - Navegação entre páginas
- **Tailwind CSS** - Estilização e layout responsivo
- **Vite** - Build tool e servidor de desenvolvimento

## 📋 Fluxo de Uso

1. **Criar Proposta** → Preencher formulário completo
2. **Visualizar Minuta** → Contrato gerado automaticamente
3. **Gerar Link** → Hash único para assinatura
4. **Acessar Link** → Página de assinatura independente
5. **Assinar** → Canvas digital + confirmação
6. **Status** → Atualizado para "Assinado"

## 💾 Persistência

- **LocalStorage** para simular dados
- Sem backend ou banco de dados
- Dados mantidos apenas na sessão do navegador

## 🎯 Objetivos Alcançados

✅ Interface profissional e responsiva  
✅ Fluxo completo de proposta → assinatura  
✅ Geração automática de contratos  
✅ Links únicos com hash  
✅ Assinatura digital simulada  
✅ Simulação de envio por e-mail  
✅ Layout corporativo Belcar  

## 🔮 Próximos Passos (Versão Final)

- Integração com backend/API
- Banco de dados real
- Geração real de PDF
- Envio real de e-mail
- Assinatura com certificação digital
- Autenticação de usuários
- Relatórios e dashboards avançados

## 📞 Suporte

Este é um protótipo para validação visual e funcional. Para implementação completa, será necessário desenvolvimento backend e integrações adicionais.