import { Link, useLocation } from 'react-router-dom'
import { useState } from 'react'

const Layout = ({ children }) => {
  const location = useLocation()
  const isSignaturePage = location.pathname.includes('/assinatura/')
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false)

  if (isSignaturePage) {
    return (
      <div style={{ minHeight: '100vh', backgroundColor: '#f8fafc' }}>
        {children}
      </div>
    )
  }

  return (
    <div style={{ minHeight: '100vh', backgroundColor: '#f8fafc' }}>
      {/* Mobile Header */}
      <header style={{
        backgroundColor: 'white',
        borderBottom: '1px solid #e2e8f0',
        position: 'sticky',
        top: 0,
        zIndex: 50,
        padding: '12px 16px'
      }}>
        <div style={{
          display: 'flex',
          justifyContent: 'space-between',
          alignItems: 'center',
          height: '48px'
        }}>
          {/* Logo */}
          <Link to="/" style={{ textDecoration: 'none' }}>
            <div style={{
              backgroundColor: '#1e40af',
              color: 'white',
              padding: '8px 16px',
              borderRadius: '8px',
              fontWeight: 'bold',
              fontSize: '18px'
            }}>
              BELCAR
            </div>
          </Link>

          {/* Mobile Menu Button */}
          <button
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            style={{
              padding: '8px',
              border: 'none',
              background: 'none',
              cursor: 'pointer'
            }}
          >
            <svg width="24" height="24" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              {mobileMenuOpen ? (
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
              ) : (
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 6h16M4 12h16M4 18h16" />
              )}
            </svg>
          </button>
        </div>

        {/* Mobile Menu */}
        {mobileMenuOpen && (
          <div style={{
            borderTop: '1px solid #e2e8f0',
            paddingTop: '12px',
            marginTop: '12px'
          }}>
            <Link
              to="/"
              onClick={() => setMobileMenuOpen(false)}
              style={{
                display: 'block',
                padding: '12px 0',
                textDecoration: 'none',
                color: '#374151',
                fontWeight: '500'
              }}
            >
              📊 Dashboard
            </Link>
            <Link
              to="/nova-proposta"
              onClick={() => setMobileMenuOpen(false)}
              style={{
                display: 'block',
                padding: '12px 16px',
                backgroundColor: '#1e40af',
                color: 'white',
                textDecoration: 'none',
                borderRadius: '8px',
                fontWeight: '600',
                marginTop: '8px'
              }}
            >
              ➕ Nova Proposta
            </Link>
          </div>
        )}
      </header>

      {/* Main Content */}
      <main className="mobile-container" style={{ paddingTop: '20px', paddingBottom: '40px' }}>
        {children}
      </main>
    </div>
  )
}

export default Layout