import { BrowserRouter as Router, Routes, Route } from 'react-router-dom'
import Dashboard from './pages/Dashboard'
import ProposalForm from './pages/ProposalForm'
import ContractPreview from './pages/ContractPreview'
import SignaturePage from './pages/SignaturePage'
import Layout from './components/Layout'

function App() {
  return (
    <Router>
      <Layout>
        <Routes>
          <Route path="/" element={<Dashboard />} />
          <Route path="/nova-proposta" element={<ProposalForm />} />
          <Route path="/contrato/:id" element={<ContractPreview />} />
          <Route path="/assinatura/:hash" element={<SignaturePage />} />
        </Routes>
      </Layout>
    </Router>
  )
}

export default App