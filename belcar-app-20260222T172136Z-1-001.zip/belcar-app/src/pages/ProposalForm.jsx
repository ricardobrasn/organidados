import { useState } from 'react'
import { useNavigate } from 'react-router-dom'
import Modal from '../components/Modal'
import { sampleProposalData, sampleProposalDataCheque } from '../utils/mockData'

const ProposalForm = () => {
  const navigate = useNavigate()
  const [showModal, setShowModal] = useState(false)
  const [modalContent, setModalContent] = useState({ title: '', message: '' })
  const [formData, setFormData] = useState({
    nome: '',
    profissao: '',
    cpfCnpj: '',
    dataNascimento: '',
    estadoCivil: '',
    endereco: '',
    cidade: '',
    estado: '',
    cep: '',
    email: '',
    telefone: '',
    modeloBem: '',
    codigo: '',
    valorBem: '',
    percentualEntrada: '',
    planoMeses: '',
    valorParcela: '',
    vencimentoDia: '',
    valorRecebido: '',
    percentualEquivalente: '',
    formaPagamento: 'Dinheiro',
    banco: '',
    agencia: '',
    numeroCheque: ''
  })

  const handleChange = (e) => {
    const { name, value } = e.target
    setFormData(prev => ({ ...prev, [name]: value }))
  }

  const loadSampleData = (sampleType) => {
    const data = sampleType === 'cheque' ? sampleProposalDataCheque : sampleProposalData
    setFormData(data)
    setModalContent({
      title: 'Dados Carregados',
      message: `Formulário preenchido com dados de exemplo.`
    })
    setShowModal(true)
  }

  const handleSubmit = (e) => {
    e.preventDefault()
    const proposalId = Date.now()
    localStorage.setItem(`proposal_${proposalId}`, JSON.stringify(formData))
    navigate(`/contrato/${proposalId}`)
  }

  const generateSignatureLink = () => {
    const hash = btoa(Date.now().toString()).replace(/[^a-zA-Z0-9]/g, '').substring(0, 16)
    const link = `${window.location.origin}/assinatura/${hash}`
    localStorage.setItem(`signature_${hash}`, JSON.stringify(formData))
    navigator.clipboard.writeText(link)
    setModalContent({
      title: 'Link Gerado',
      message: `Link copiado!\n\n${link}`
    })
    setShowModal(true)
  }

  const simulateEmailSend = () => {
    if (!formData.email) {
      setModalContent({
        title: 'Erro',
        message: 'Preencha o e-mail do cliente.'
      })
      setShowModal(true)
      return
    }
    setModalContent({
      title: 'E-mail Enviado',
      message: `E-mail enviado para ${formData.email}!`
    })
    setShowModal(true)
  }

  return (
    <div>
      {/* Header */}
      <div style={{ marginBottom: '24px' }}>
        <h1 style={{
          fontSize: '28px',
          fontWeight: 'bold',
          color: '#1e3a8a',
          margin: '0 0 8px 0'
        }}>
          Nova Proposta
        </h1>
        <p style={{
          color: '#6b7280',
          margin: '0 0 20px 0'
        }}>
          Preencha os dados para gerar a proposta
        </p>

        {/* Sample Buttons */}
        <button
          onClick={() => loadSampleData('dinheiro')}
          className="mobile-button"
          style={{
            backgroundColor: '#10b981',
            color: 'white'
          }}
        >
          📄 Exemplo (Dinheiro)
        </button>
        <button
          onClick={() => loadSampleData('cheque')}
          className="mobile-button"
          style={{
            backgroundColor: '#8b5cf6',
            color: 'white'
          }}
        >
          📄 Exemplo (Cheque)
        </button>
      </div>

      <form onSubmit={handleSubmit}>
        {/* Dados do Comprador */}
        <div className="mobile-card">
          <h2 style={{
            fontSize: '20px',
            fontWeight: '600',
            marginBottom: '20px',
            color: '#374151',
            display: 'flex',
            alignItems: 'center',
            gap: '8px'
          }}>
            <span style={{
              backgroundColor: '#1e40af',
              color: 'white',
              borderRadius: '50%',
              width: '24px',
              height: '24px',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              fontSize: '14px'
            }}>1</span>
            Dados do Comprador
          </h2>

          <label className="mobile-label">Nome Completo *</label>
          <input
            type="text"
            name="nome"
            value={formData.nome}
            onChange={handleChange}
            className="mobile-input"
            placeholder="Digite o nome completo"
            required
          />

          <label className="mobile-label">Profissão *</label>
          <input
            type="text"
            name="profissao"
            value={formData.profissao}
            onChange={handleChange}
            className="mobile-input"
            placeholder="Digite a profissão"
            required
          />

          <label className="mobile-label">CPF/CNPJ *</label>
          <input
            type="text"
            name="cpfCnpj"
            value={formData.cpfCnpj}
            onChange={handleChange}
            className="mobile-input"
            placeholder="000.000.000-00"
            required
          />

          <label className="mobile-label">Data de Nascimento *</label>
          <input
            type="date"
            name="dataNascimento"
            value={formData.dataNascimento}
            onChange={handleChange}
            className="mobile-input"
            required
          />

          <label className="mobile-label">Estado Civil *</label>
          <select
            name="estadoCivil"
            value={formData.estadoCivil}
            onChange={handleChange}
            className="mobile-input"
            required
          >
            <option value="">Selecione</option>
            <option value="Solteiro(a)">Solteiro(a)</option>
            <option value="Casado(a)">Casado(a)</option>
            <option value="Divorciado(a)">Divorciado(a)</option>
            <option value="Viúvo(a)">Viúvo(a)</option>
          </select>

          <label className="mobile-label">E-mail *</label>
          <input
            type="email"
            name="email"
            value={formData.email}
            onChange={handleChange}
            className="mobile-input"
            placeholder="email@exemplo.com"
            required
          />

          <label className="mobile-label">Telefone *</label>
          <input
            type="tel"
            name="telefone"
            value={formData.telefone}
            onChange={handleChange}
            className="mobile-input"
            placeholder="(11) 99999-9999"
            required
          />

          <label className="mobile-label">Endereço Completo *</label>
          <input
            type="text"
            name="endereco"
            value={formData.endereco}
            onChange={handleChange}
            className="mobile-input"
            placeholder="Rua, número, bairro"
            required
          />

          <div style={{ display: 'grid', gridTemplateColumns: '1fr 80px', gap: '12px' }}>
            <div>
              <label className="mobile-label">Cidade *</label>
              <input
                type="text"
                name="cidade"
                value={formData.cidade}
                onChange={handleChange}
                className="mobile-input"
                placeholder="Cidade"
                required
              />
            </div>
            <div>
              <label className="mobile-label">UF *</label>
              <input
                type="text"
                name="estado"
                value={formData.estado}
                onChange={handleChange}
                className="mobile-input"
                placeholder="SP"
                maxLength="2"
                required
              />
            </div>
          </div>

          <label className="mobile-label">CEP *</label>
          <input
            type="text"
            name="cep"
            value={formData.cep}
            onChange={handleChange}
            className="mobile-input"
            placeholder="00000-000"
            required
          />
        </div>

        {/* Condições da Venda */}
        <div className="mobile-card">
          <h2 style={{
            fontSize: '20px',
            fontWeight: '600',
            marginBottom: '20px',
            color: '#374151',
            display: 'flex',
            alignItems: 'center',
            gap: '8px'
          }}>
            <span style={{
              backgroundColor: '#1e40af',
              color: 'white',
              borderRadius: '50%',
              width: '24px',
              height: '24px',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              fontSize: '14px'
            }}>2</span>
            Condições da Venda
          </h2>

          <label className="mobile-label">Modelo do Bem *</label>
          <input
            type="text"
            name="modeloBem"
            value={formData.modeloBem}
            onChange={handleChange}
            className="mobile-input"
            placeholder="Ex: Honda Civic 2024"
            required
          />

          <label className="mobile-label">Código *</label>
          <input
            type="text"
            name="codigo"
            value={formData.codigo}
            onChange={handleChange}
            className="mobile-input"
            placeholder="Código do veículo"
            required
          />

          <label className="mobile-label">Valor do Bem (R$) *</label>
          <input
            type="number"
            step="0.01"
            name="valorBem"
            value={formData.valorBem}
            onChange={handleChange}
            className="mobile-input"
            placeholder="0,00"
            required
          />

          <label className="mobile-label">% Pago para Entrega *</label>
          <input
            type="number"
            step="0.01"
            name="percentualEntrada"
            value={formData.percentualEntrada}
            onChange={handleChange}
            className="mobile-input"
            placeholder="30"
            required
          />

          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '12px' }}>
            <div>
              <label className="mobile-label">Plano (meses) *</label>
              <input
                type="number"
                name="planoMeses"
                value={formData.planoMeses}
                onChange={handleChange}
                className="mobile-input"
                placeholder="48"
                required
              />
            </div>
            <div>
              <label className="mobile-label">Vencimento (dia) *</label>
              <input
                type="number"
                min="1"
                max="31"
                name="vencimentoDia"
                value={formData.vencimentoDia}
                onChange={handleChange}
                className="mobile-input"
                placeholder="10"
                required
              />
            </div>
          </div>

          <label className="mobile-label">Valor da Parcela (R$) *</label>
          <input
            type="number"
            step="0.01"
            name="valorParcela"
            value={formData.valorParcela}
            onChange={handleChange}
            className="mobile-input"
            placeholder="0,00"
            required
          />
        </div>

        {/* Recibo */}
        <div className="mobile-card">
          <h2 style={{
            fontSize: '20px',
            fontWeight: '600',
            marginBottom: '20px',
            color: '#374151',
            display: 'flex',
            alignItems: 'center',
            gap: '8px'
          }}>
            <span style={{
              backgroundColor: '#1e40af',
              color: 'white',
              borderRadius: '50%',
              width: '24px',
              height: '24px',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              fontSize: '14px'
            }}>3</span>
            Recibo
          </h2>

          <label className="mobile-label">Valor Recebido (R$) *</label>
          <input
            type="number"
            step="0.01"
            name="valorRecebido"
            value={formData.valorRecebido}
            onChange={handleChange}
            className="mobile-input"
            placeholder="0,00"
            required
          />

          <label className="mobile-label">Percentual Equivalente (%) *</label>
          <input
            type="number"
            step="0.01"
            name="percentualEquivalente"
            value={formData.percentualEquivalente}
            onChange={handleChange}
            className="mobile-input"
            placeholder="30"
            required
          />

          <label className="mobile-label">Forma de Pagamento *</label>
          <select
            name="formaPagamento"
            value={formData.formaPagamento}
            onChange={handleChange}
            className="mobile-input"
            required
          >
            <option value="Dinheiro">💵 Dinheiro</option>
            <option value="Cheque">📝 Cheque</option>
          </select>

          {formData.formaPagamento === 'Cheque' && (
            <div style={{
              backgroundColor: '#f9fafb',
              padding: '16px',
              borderRadius: '8px',
              marginTop: '16px'
            }}>
              <h3 style={{ margin: '0 0 16px 0', fontWeight: '600' }}>Dados do Cheque</h3>
              
              <label className="mobile-label">Banco</label>
              <input
                type="text"
                name="banco"
                value={formData.banco}
                onChange={handleChange}
                className="mobile-input"
                placeholder="Nome do banco"
              />

              <label className="mobile-label">Agência</label>
              <input
                type="text"
                name="agencia"
                value={formData.agencia}
                onChange={handleChange}
                className="mobile-input"
                placeholder="0000-0"
              />

              <label className="mobile-label">Nº do Cheque</label>
              <input
                type="text"
                name="numeroCheque"
                value={formData.numeroCheque}
                onChange={handleChange}
                className="mobile-input"
                placeholder="000000"
              />
            </div>
          )}
        </div>

        {/* Action Buttons */}
        <button
          type="submit"
          className="mobile-button"
          style={{
            backgroundColor: '#1e40af',
            color: 'white',
            boxShadow: '0 4px 12px rgba(30, 64, 175, 0.3)'
          }}
        >
          📄 Visualizar Minuta
        </button>

        <button
          type="button"
          onClick={generateSignatureLink}
          className="mobile-button"
          style={{
            backgroundColor: '#10b981',
            color: 'white'
          }}
        >
          🔗 Gerar Link de Assinatura
        </button>

        <button
          type="button"
          onClick={simulateEmailSend}
          className="mobile-button"
          style={{
            backgroundColor: '#8b5cf6',
            color: 'white'
          }}
        >
          📧 Simular Envio por Email
        </button>
      </form>

      <Modal 
        isOpen={showModal} 
        onClose={() => setShowModal(false)}
        title={modalContent.title}
      >
        <p style={{ color: '#6b7280', whiteSpace: 'pre-line' }}>{modalContent.message}</p>
        <div style={{ marginTop: '16px', textAlign: 'right' }}>
          <button
            onClick={() => setShowModal(false)}
            style={{
              backgroundColor: '#1e40af',
              color: 'white',
              border: 'none',
              padding: '8px 16px',
              borderRadius: '6px',
              cursor: 'pointer'
            }}
          >
            OK
          </button>
        </div>
      </Modal>
    </div>
  )
}

export default ProposalForm