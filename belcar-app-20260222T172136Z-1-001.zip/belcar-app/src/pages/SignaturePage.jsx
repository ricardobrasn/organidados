import { useParams, useNavigate } from 'react-router-dom'
import { useState, useEffect, useRef } from 'react'

const SignaturePage = () => {
  const { hash } = useParams()
  const navigate = useNavigate()
  const canvasRef = useRef(null)
  const [contractData, setContractData] = useState(null)
  const [isDrawing, setIsDrawing] = useState(false)
  const [isSigned, setIsSigned] = useState(false)

  useEffect(() => {
    const savedData = localStorage.getItem(`signature_${hash}`)
    if (savedData) {
      setContractData(JSON.parse(savedData))
    } else {
      setContractData({
        nome: 'João Silva Santos',
        cpfCnpj: '123.456.789-00',
        endereco: 'Rua das Flores, 123',
        cidade: 'São Paulo',
        estado: 'SP',
        modeloBem: 'Honda Civic 2024',
        valorBem: '85000.00',
        percentualEntrada: '30',
        planoMeses: '48',
        valorParcela: '1250.00',
        vencimentoDia: '10',
        valorRecebido: '25500.00',
        percentualEquivalente: '30',
        formaPagamento: 'Dinheiro'
      })
    }

    // Setup canvas
    setTimeout(() => {
      const canvas = canvasRef.current
      if (canvas) {
        const ctx = canvas.getContext('2d')
        ctx.strokeStyle = '#000'
        ctx.lineWidth = 3
        ctx.lineCap = 'round'
        ctx.lineJoin = 'round'
        
        // Set canvas size
        const rect = canvas.getBoundingClientRect()
        canvas.width = rect.width
        canvas.height = 150
      }
    }, 100)
  }, [hash])

  const getEventPos = (e) => {
    const canvas = canvasRef.current
    const rect = canvas.getBoundingClientRect()
    const clientX = e.touches ? e.touches[0].clientX : e.clientX
    const clientY = e.touches ? e.touches[0].clientY : e.clientY
    
    return {
      x: clientX - rect.left,
      y: clientY - rect.top
    }
  }

  const startDrawing = (e) => {
    e.preventDefault()
    setIsDrawing(true)
    const canvas = canvasRef.current
    const ctx = canvas.getContext('2d')
    const pos = getEventPos(e)
    
    ctx.beginPath()
    ctx.moveTo(pos.x, pos.y)
  }

  const draw = (e) => {
    if (!isDrawing) return
    e.preventDefault()
    
    const canvas = canvasRef.current
    const ctx = canvas.getContext('2d')
    const pos = getEventPos(e)
    
    ctx.lineTo(pos.x, pos.y)
    ctx.stroke()
  }

  const stopDrawing = (e) => {
    e.preventDefault()
    setIsDrawing(false)
  }

  const clearSignature = () => {
    const canvas = canvasRef.current
    const ctx = canvas.getContext('2d')
    ctx.clearRect(0, 0, canvas.width, canvas.height)
  }

  const confirmSignature = () => {
    const canvas = canvasRef.current
    const imageData = canvas.toDataURL()
    
    localStorage.setItem(`signed_${hash}`, JSON.stringify({
      ...contractData,
      signature: imageData,
      signedAt: new Date().toISOString()
    }))
    
    setIsSigned(true)
    
    setTimeout(() => {
      navigate('/')
    }, 2000)
  }

  if (!contractData) {
    return (
      <div style={{
        minHeight: '100vh',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        backgroundColor: '#f8fafc',
        padding: '16px'
      }}>
        <div style={{ textAlign: 'center' }}>
          <div style={{
            width: '40px',
            height: '40px',
            border: '3px solid #f3f4f6',
            borderTop: '3px solid #1e40af',
            borderRadius: '50%',
            animation: 'spin 1s linear infinite',
            margin: '0 auto 16px'
          }}></div>
          <p style={{ color: '#6b7280' }}>Carregando contrato...</p>
        </div>
      </div>
    )
  }

  if (isSigned) {
    return (
      <div style={{
        minHeight: '100vh',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        backgroundColor: '#f0fdf4',
        padding: '16px'
      }}>
        <div style={{ textAlign: 'center', maxWidth: '320px' }}>
          <div style={{
            width: '80px',
            height: '80px',
            backgroundColor: '#10b981',
            borderRadius: '50%',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            margin: '0 auto 24px'
          }}>
            <svg width="40" height="40" fill="none" stroke="white" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={3} d="M5 13l4 4L19 7" />
            </svg>
          </div>
          <h1 style={{
            fontSize: '24px',
            fontWeight: 'bold',
            color: '#065f46',
            margin: '0 0 12px 0'
          }}>
            Contrato Assinado!
          </h1>
          <p style={{
            color: '#059669',
            margin: '0 0 16px 0'
          }}>
            Sua assinatura foi registrada com sucesso.
          </p>
          <div style={{
            color: '#059669',
            fontSize: '14px',
            animation: 'pulse 2s infinite'
          }}>
            Redirecionando...
          </div>
        </div>
      </div>
    )
  }

  return (
    <div style={{
      minHeight: '100vh',
      backgroundColor: '#f8fafc',
      padding: '16px'
    }}>
      <div style={{ maxWidth: '600px', margin: '0 auto' }}>
        {/* Header */}
        <div style={{ textAlign: 'center', marginBottom: '24px' }}>
          <div style={{
            backgroundColor: '#1e40af',
            color: 'white',
            padding: '12px 20px',
            borderRadius: '8px',
            fontWeight: 'bold',
            fontSize: '18px',
            display: 'inline-block',
            marginBottom: '12px'
          }}>
            BELCAR INVESTCAR
          </div>
          <h1 style={{
            fontSize: '24px',
            fontWeight: 'bold',
            color: '#374151',
            margin: '0 0 8px 0'
          }}>
            Assinatura Digital
          </h1>
          <p style={{
            color: '#6b7280',
            fontSize: '14px',
            margin: 0
          }}>
            Hash: {hash}
          </p>
        </div>

        {/* Contract Summary */}
        <div className="mobile-card">
          <h2 style={{
            fontSize: '18px',
            fontWeight: '600',
            marginBottom: '16px',
            color: '#374151',
            display: 'flex',
            alignItems: 'center',
            gap: '8px'
          }}>
            📋 Resumo do Contrato
          </h2>
          <div style={{ fontSize: '14px', lineHeight: '1.6' }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '8px' }}>
              <span style={{ color: '#6b7280' }}>Cliente:</span>
              <span style={{ fontWeight: '600' }}>{contractData.nome}</span>
            </div>
            <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '8px' }}>
              <span style={{ color: '#6b7280' }}>CPF/CNPJ:</span>
              <span style={{ fontWeight: '600' }}>{contractData.cpfCnpj}</span>
            </div>
            <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '8px' }}>
              <span style={{ color: '#6b7280' }}>Veículo:</span>
              <span style={{ fontWeight: '600' }}>{contractData.modeloBem}</span>
            </div>
            <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '8px' }}>
              <span style={{ color: '#6b7280' }}>Valor Total:</span>
              <span style={{ fontWeight: '600', color: '#1e40af' }}>
                R$ {parseFloat(contractData.valorBem).toLocaleString('pt-BR', { minimumFractionDigits: 2 })}
              </span>
            </div>
            <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '8px' }}>
              <span style={{ color: '#6b7280' }}>Entrada:</span>
              <span style={{ fontWeight: '600' }}>
                R$ {parseFloat(contractData.valorRecebido).toLocaleString('pt-BR', { minimumFractionDigits: 2 })}
              </span>
            </div>
            <div style={{ display: 'flex', justifyContent: 'space-between' }}>
              <span style={{ color: '#6b7280' }}>Parcelas:</span>
              <span style={{ fontWeight: '600' }}>
                {contractData.planoMeses}x de R$ {parseFloat(contractData.valorParcela).toLocaleString('pt-BR', { minimumFractionDigits: 2 })}
              </span>
            </div>
          </div>
        </div>

        {/* Contract Terms */}
        <div className="mobile-card">
          <h2 style={{
            fontSize: '18px',
            fontWeight: '600',
            marginBottom: '16px',
            color: '#374151',
            display: 'flex',
            alignItems: 'center',
            gap: '8px'
          }}>
            📄 Termos do Contrato
          </h2>
          <div style={{
            fontSize: '12px',
            lineHeight: '1.5',
            maxHeight: '200px',
            overflowY: 'auto',
            border: '1px solid #e5e7eb',
            padding: '12px',
            borderRadius: '6px',
            backgroundColor: '#f9fafb'
          }}>
            <div style={{ marginBottom: '12px' }}>
              <h4 style={{ fontWeight: '600', color: '#1e40af', margin: '0 0 8px 0' }}>
                CONTRATO DE FINANCIAMENTO DE VEÍCULO
              </h4>
            </div>
            <p style={{ textAlign: 'justify', marginBottom: '12px' }}>
              <strong>BELCAR INVESTCAR LTDA</strong> e <strong>{contractData.nome.toUpperCase()}</strong> 
              acordam o financiamento do veículo <strong>{contractData.modeloBem}</strong> no valor de 
              <strong> R$ {parseFloat(contractData.valorBem).toLocaleString('pt-BR', { minimumFractionDigits: 2 })}</strong>.
            </p>
            <p style={{ textAlign: 'justify', marginBottom: '12px' }}>
              <strong>FORMA DE PAGAMENTO:</strong> Entrada de {contractData.percentualEntrada}% 
              (R$ {parseFloat(contractData.valorRecebido).toLocaleString('pt-BR', { minimumFractionDigits: 2 })}) 
              e saldo em {contractData.planoMeses} parcelas de 
              R$ {parseFloat(contractData.valorParcela).toLocaleString('pt-BR', { minimumFractionDigits: 2 })}, 
              vencimento dia {contractData.vencimentoDia} de cada mês.
            </p>
            <p style={{ textAlign: 'justify', marginBottom: '12px' }}>
              O não pagamento de qualquer parcela implicará em multa de 2% e juros de 1% ao mês.
            </p>
            <p style={{ textAlign: 'justify', margin: 0 }}>
              <strong>DECLARAÇÃO:</strong> O financiado declara estar ciente de todas as cláusulas deste contrato.
            </p>
          </div>
        </div>

        {/* Signature Area */}
        <div className="mobile-card">
          <h2 style={{
            fontSize: '18px',
            fontWeight: '600',
            marginBottom: '16px',
            color: '#374151',
            display: 'flex',
            alignItems: 'center',
            gap: '8px'
          }}>
            ✍️ Assinatura Digital
          </h2>
          <p style={{
            color: '#6b7280',
            marginBottom: '16px',
            fontSize: '14px'
          }}>
            Desenhe sua assinatura no campo abaixo:
          </p>
          
          {/* Canvas */}
          <div style={{
            border: '2px dashed #d1d5db',
            borderRadius: '8px',
            padding: '8px',
            marginBottom: '16px',
            backgroundColor: '#f9fafb'
          }}>
            <canvas
              ref={canvasRef}
              style={{
                width: '100%',
                height: '150px',
                border: '1px solid #e5e7eb',
                borderRadius: '4px',
                backgroundColor: 'white',
                cursor: 'crosshair',
                touchAction: 'none'
              }}
              onMouseDown={startDrawing}
              onMouseMove={draw}
              onMouseUp={stopDrawing}
              onMouseLeave={stopDrawing}
              onTouchStart={startDrawing}
              onTouchMove={draw}
              onTouchEnd={stopDrawing}
            />
          </div>

          {/* Action Buttons */}
          <button
            onClick={clearSignature}
            className="mobile-button"
            style={{
              backgroundColor: '#6b7280',
              color: 'white'
            }}
          >
            🗑️ Limpar Assinatura
          </button>

          <button
            onClick={confirmSignature}
            className="mobile-button"
            style={{
              backgroundColor: '#1e40af',
              color: 'white',
              boxShadow: '0 4px 12px rgba(30, 64, 175, 0.3)'
            }}
          >
            ✅ Confirmar Assinatura
          </button>
        </div>

        {/* Important Notice */}
        <div style={{
          backgroundColor: '#fef3c7',
          border: '1px solid #f59e0b',
          borderRadius: '8px',
          padding: '16px'
        }}>
          <div style={{ display: 'flex', alignItems: 'flex-start', gap: '8px' }}>
            <svg width="20" height="20" fill="none" stroke="#d97706" viewBox="0 0 24 24" style={{ flexShrink: 0, marginTop: '2px' }}>
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-2.5L13.732 4c-.77-.833-1.964-.833-2.732 0L3.732 16.5c-.77.833.192 2.5 1.732 2.5z" />
            </svg>
            <div>
              <p style={{
                fontSize: '14px',
                color: '#92400e',
                margin: 0,
                lineHeight: '1.5'
              }}>
                <strong>Importante:</strong> Ao confirmar a assinatura, você estará concordando com todos os termos e condições do contrato de financiamento.
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}

export default SignaturePage