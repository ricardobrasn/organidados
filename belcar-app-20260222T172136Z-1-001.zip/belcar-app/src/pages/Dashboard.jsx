import { useState } from 'react'
import { Link } from 'react-router-dom'

const Dashboard = () => {
  const [proposals] = useState([
    {
      id: 1,
      numero: 'PROP-2024-001',
      cliente: 'João Silva Santos',
      modelo: 'Honda Civic 2024',
      status: 'Rascunho',
      statusColor: '#f59e0b'
    },
    {
      id: 2,
      numero: 'PROP-2024-002',
      cliente: 'Maria Oliveira Costa',
      modelo: 'Toyota Corolla 2024',
      status: 'Aguardando Assinatura',
      statusColor: '#3b82f6'
    },
    {
      id: 3,
      numero: 'PROP-2024-003',
      cliente: 'Carlos Eduardo Lima',
      modelo: 'Volkswagen Jetta 2024',
      status: 'Assinado',
      statusColor: '#10b981'
    }
  ])

  return (
    <div>
      {/* Header */}
      <div style={{ marginBottom: '24px' }}>
        <h1 style={{
          fontSize: '28px',
          fontWeight: 'bold',
          color: '#1e3a8a',
          margin: '0 0 8px 0'
        }}>
          Dashboard
        </h1>
        <p style={{
          color: '#6b7280',
          margin: '0 0 20px 0'
        }}>
          Gerencie suas propostas de financiamento
        </p>

        {/* CTA Button */}
        <Link
          to="/nova-proposta"
          className="mobile-button"
          style={{
            backgroundColor: '#1e40af',
            color: 'white',
            textDecoration: 'none',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            gap: '8px',
            boxShadow: '0 4px 12px rgba(30, 64, 175, 0.3)'
          }}
        >
          <span style={{ fontSize: '20px' }}>➕</span>
          Nova Proposta
        </Link>
      </div>

      {/* Stats */}
      <div style={{ marginBottom: '24px' }}>
        <h2 style={{
          fontSize: '20px',
          fontWeight: '600',
          marginBottom: '16px',
          color: '#374151'
        }}>
          Estatísticas
        </h2>

        <div className="mobile-card" style={{ borderLeft: '4px solid #3b82f6' }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
            <div>
              <p style={{ color: '#6b7280', margin: '0 0 4px 0', fontSize: '14px' }}>Total de Propostas</p>
              <p style={{ fontSize: '32px', fontWeight: 'bold', color: '#111827', margin: 0 }}>{proposals.length}</p>
            </div>
            <div style={{
              backgroundColor: '#dbeafe',
              padding: '12px',
              borderRadius: '50%'
            }}>
              <svg width="24" height="24" fill="none" stroke="#3b82f6" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
              </svg>
            </div>
          </div>
        </div>

        <div className="mobile-card" style={{ borderLeft: '4px solid #f59e0b' }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
            <div>
              <p style={{ color: '#6b7280', margin: '0 0 4px 0', fontSize: '14px' }}>Aguardando Assinatura</p>
              <p style={{ fontSize: '32px', fontWeight: 'bold', color: '#111827', margin: 0 }}>
                {proposals.filter(p => p.status === 'Aguardando Assinatura').length}
              </p>
            </div>
            <div style={{
              backgroundColor: '#fef3c7',
              padding: '12px',
              borderRadius: '50%'
            }}>
              <svg width="24" height="24" fill="none" stroke="#f59e0b" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" />
              </svg>
            </div>
          </div>
        </div>

        <div className="mobile-card" style={{ borderLeft: '4px solid #10b981' }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
            <div>
              <p style={{ color: '#6b7280', margin: '0 0 4px 0', fontSize: '14px' }}>Contratos Assinados</p>
              <p style={{ fontSize: '32px', fontWeight: 'bold', color: '#111827', margin: 0 }}>
                {proposals.filter(p => p.status === 'Assinado').length}
              </p>
            </div>
            <div style={{
              backgroundColor: '#d1fae5',
              padding: '12px',
              borderRadius: '50%'
            }}>
              <svg width="24" height="24" fill="none" stroke="#10b981" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
              </svg>
            </div>
          </div>
        </div>
      </div>

      {/* Proposals */}
      <div>
        <h2 style={{
          fontSize: '20px',
          fontWeight: '600',
          marginBottom: '16px',
          color: '#374151'
        }}>
          Propostas Recentes
        </h2>

        {proposals.map((proposal) => (
          <div key={proposal.id} className="mobile-card">
            <div style={{ marginBottom: '12px' }}>
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: '8px' }}>
                <div>
                  <p style={{ fontWeight: '600', color: '#111827', margin: '0 0 4px 0' }}>{proposal.numero}</p>
                  <p style={{ color: '#6b7280', margin: 0, fontSize: '14px' }}>{proposal.cliente}</p>
                </div>
                <span style={{
                  backgroundColor: proposal.statusColor,
                  color: 'white',
                  padding: '4px 12px',
                  borderRadius: '20px',
                  fontSize: '12px',
                  fontWeight: '600'
                }}>
                  {proposal.status}
                </span>
              </div>
              <p style={{ color: '#6b7280', margin: '8px 0 0 0', fontSize: '14px' }}>{proposal.modelo}</p>
            </div>

            <div style={{ display: 'flex', gap: '8px', paddingTop: '12px', borderTop: '1px solid #f3f4f6' }}>
              <Link
                to={`/contrato/${proposal.id}`}
                style={{
                  flex: 1,
                  backgroundColor: '#1e40af',
                  color: 'white',
                  textDecoration: 'none',
                  padding: '12px',
                  borderRadius: '6px',
                  textAlign: 'center',
                  fontWeight: '600',
                  fontSize: '14px'
                }}
              >
                Visualizar
              </Link>
              <button style={{
                flex: 1,
                backgroundColor: '#f3f4f6',
                color: '#374151',
                border: 'none',
                padding: '12px',
                borderRadius: '6px',
                fontWeight: '600',
                fontSize: '14px',
                cursor: 'pointer'
              }}>
                Editar
              </button>
            </div>
          </div>
        ))}
      </div>
    </div>
  )
}

export default Dashboard