import { useParams, useNavigate } from 'react-router-dom'
import { useState, useEffect } from 'react'
import Modal from '../components/Modal'

const ContractPreview = () => {
  const { id } = useParams()
  const navigate = useNavigate()
  const [contractData, setContractData] = useState(null)
  const [showModal, setShowModal] = useState(false)
  const [modalContent, setModalContent] = useState({ title: '', message: '' })

  useEffect(() => {
    const savedData = localStorage.getItem(`proposal_${id}`)
    if (savedData) {
      setContractData(JSON.parse(savedData))
    } else {
      setContractData({
        nome: 'João Silva Santos',
        cpfCnpj: '123.456.789-00',
        endereco: 'Rua das Flores, 123',
        cidade: 'São Paulo',
        estado: 'SP',
        modeloBem: 'Honda Civic 2024',
        valorBem: '85000.00',
        percentualEntrada: '30',
        planoMeses: '48',
        valorParcela: '1250.00',
        vencimentoDia: '10',
        valorRecebido: '25500.00',
        percentualEquivalente: '30',
        formaPagamento: 'Dinheiro'
      })
    }
  }, [id])

  const generateSignatureLink = () => {
    const hash = btoa(Date.now().toString()).replace(/[^a-zA-Z0-9]/g, '').substring(0, 16)
    const link = `${window.location.origin}/assinatura/${hash}`
    localStorage.setItem(`signature_${hash}`, JSON.stringify(contractData))
    navigator.clipboard.writeText(link)
    setModalContent({
      title: 'Link Gerado',
      message: `Link copiado!\n\n${link}`
    })
    setShowModal(true)
  }

  const generatePDF = () => {
    setModalContent({
      title: 'Geração de PDF',
      message: 'Funcionalidade será implementada na versão final.'
    })
    setShowModal(true)
  }

  if (!contractData) {
    return (
      <div style={{ textAlign: 'center', padding: '40px' }}>
        <div style={{
          width: '40px',
          height: '40px',
          border: '3px solid #f3f4f6',
          borderTop: '3px solid #1e40af',
          borderRadius: '50%',
          animation: 'spin 1s linear infinite',
          margin: '0 auto 16px'
        }}></div>
        <p>Carregando contrato...</p>
      </div>
    )
  }

  return (
    <div>
      {/* Header */}
      <div style={{ marginBottom: '24px' }}>
        <h1 style={{
          fontSize: '28px',
          fontWeight: 'bold',
          color: '#1e3a8a',
          margin: '0 0 8px 0'
        }}>
          Minuta do Contrato
        </h1>
        <p style={{
          color: '#6b7280',
          margin: '0 0 20px 0'
        }}>
          Proposta #{id}
        </p>

        {/* Action Buttons */}
        <button
          onClick={() => navigate(-1)}
          className="mobile-button"
          style={{
            backgroundColor: '#6b7280',
            color: 'white'
          }}
        >
          ← Voltar
        </button>

        <button
          onClick={generatePDF}
          className="mobile-button"
          style={{
            backgroundColor: '#dc2626',
            color: 'white'
          }}
        >
          📄 Gerar PDF
        </button>

        <button
          onClick={generateSignatureLink}
          className="mobile-button"
          style={{
            backgroundColor: '#1e40af',
            color: 'white',
            boxShadow: '0 4px 12px rgba(30, 64, 175, 0.3)'
          }}
        >
          ✍️ Enviar para Assinatura
        </button>
      </div>

      {/* Contract Content */}
      <div className="mobile-card">
        {/* Header */}
        <div style={{ textAlign: 'center', marginBottom: '24px', paddingBottom: '16px', borderBottom: '2px solid #f3f4f6' }}>
          <div style={{
            backgroundColor: '#1e40af',
            color: 'white',
            padding: '12px 20px',
            borderRadius: '8px',
            fontWeight: 'bold',
            fontSize: '18px',
            display: 'inline-block',
            marginBottom: '12px'
          }}>
            BELCAR INVESTCAR
          </div>
          <h2 style={{
            fontSize: '16px',
            fontWeight: 'bold',
            color: '#374151',
            margin: 0,
            lineHeight: '1.4'
          }}>
            CONTRATO DE FINANCIAMENTO DE VEÍCULO
          </h2>
        </div>

        {/* Summary */}
        <div style={{
          backgroundColor: '#f8fafc',
          padding: '16px',
          borderRadius: '8px',
          marginBottom: '20px'
        }}>
          <h3 style={{
            fontSize: '16px',
            fontWeight: '600',
            marginBottom: '12px',
            color: '#1e40af'
          }}>
            📋 Resumo do Contrato
          </h3>
          <div style={{ fontSize: '14px', lineHeight: '1.6' }}>
            <p style={{ margin: '4px 0' }}><strong>Cliente:</strong> {contractData.nome}</p>
            <p style={{ margin: '4px 0' }}><strong>Documento:</strong> {contractData.cpfCnpj}</p>
            <p style={{ margin: '4px 0' }}><strong>Veículo:</strong> {contractData.modeloBem}</p>
            <p style={{ margin: '4px 0' }}><strong>Valor Total:</strong> R$ {parseFloat(contractData.valorBem).toLocaleString('pt-BR', { minimumFractionDigits: 2 })}</p>
            <p style={{ margin: '4px 0' }}><strong>Entrada:</strong> R$ {parseFloat(contractData.valorRecebido).toLocaleString('pt-BR', { minimumFractionDigits: 2 })}</p>
            <p style={{ margin: '4px 0' }}><strong>Parcelas:</strong> {contractData.planoMeses}x de R$ {parseFloat(contractData.valorParcela).toLocaleString('pt-BR', { minimumFractionDigits: 2 })}</p>
          </div>
        </div>

        {/* Contract Text */}
        <div style={{ fontSize: '14px', lineHeight: '1.6', color: '#374151' }}>
          <p style={{ textAlign: 'justify', marginBottom: '16px' }}>
            Pelo presente instrumento particular, de um lado <strong>BELCAR INVESTCAR LTDA</strong>, 
            pessoa jurídica de direito privado, inscrita no CNPJ sob nº 12.345.678/0001-90, 
            com sede na Rua Exemplo, 456, São Paulo/SP, doravante denominada <strong>FINANCIADORA</strong>, 
            e de outro lado <strong>{contractData.nome.toUpperCase()}</strong>, 
            {contractData.cpfCnpj.length > 14 ? 'pessoa jurídica' : 'pessoa física'}, 
            inscrit{contractData.cpfCnpj.length > 14 ? 'a' : 'o'} no {contractData.cpfCnpj.length > 14 ? 'CNPJ' : 'CPF'} 
            sob nº {contractData.cpfCnpj}, residente e domiciliad{contractData.cpfCnpj.length > 14 ? 'a' : 'o'} 
            à {contractData.endereco}, {contractData.cidade}/{contractData.estado}, 
            doravante denominad{contractData.cpfCnpj.length > 14 ? 'a' : 'o'} <strong>FINANCIAD{contractData.cpfCnpj.length > 14 ? 'A' : 'O'}</strong>, 
            têm entre si justo e acordado o presente contrato de financiamento.
          </p>

          <div style={{ backgroundColor: '#dbeafe', padding: '12px', borderRadius: '6px', marginBottom: '16px' }}>
            <h3 style={{ fontWeight: '600', color: '#1e40af', marginBottom: '8px', fontSize: '14px' }}>🎯 CLÁUSULA PRIMEIRA – OBJETO</h3>
            <p style={{ margin: 0, textAlign: 'justify' }}>
              O presente contrato tem por objeto o financiamento do veículo <strong>{contractData.modeloBem}</strong>, 
              no valor total de <strong>R$ {parseFloat(contractData.valorBem).toLocaleString('pt-BR', { minimumFractionDigits: 2 })}</strong>.
            </p>
          </div>

          <div style={{ backgroundColor: '#d1fae5', padding: '12px', borderRadius: '6px', marginBottom: '16px' }}>
            <h3 style={{ fontWeight: '600', color: '#059669', marginBottom: '8px', fontSize: '14px' }}>💰 CLÁUSULA SEGUNDA – PREÇO E FORMA DE PAGAMENTO</h3>
            <p style={{ margin: '0 0 8px 0', textAlign: 'justify' }}>O valor do financiamento será pago da seguinte forma:</p>
            <ul style={{ margin: 0, paddingLeft: '16px' }}>
              <li style={{ marginBottom: '4px' }}>
                Entrada de <strong>{contractData.percentualEntrada}%</strong> do valor total, 
                correspondente a <strong>R$ {parseFloat(contractData.valorRecebido).toLocaleString('pt-BR', { minimumFractionDigits: 2 })}</strong>, 
                pago em {contractData.formaPagamento.toLowerCase()};
              </li>
              <li>
                Saldo remanescente em <strong>{contractData.planoMeses} parcelas mensais</strong> 
                de <strong>R$ {parseFloat(contractData.valorParcela).toLocaleString('pt-BR', { minimumFractionDigits: 2 })}</strong>, 
                vencimento dia <strong>{contractData.vencimentoDia}</strong> de cada mês.
              </li>
            </ul>
          </div>

          <div style={{ backgroundColor: '#fef3c7', padding: '12px', borderRadius: '6px', marginBottom: '16px' }}>
            <h3 style={{ fontWeight: '600', color: '#d97706', marginBottom: '8px', fontSize: '14px' }}>📈 CLÁUSULA TERCEIRA – AJUSTE DAS PARCELAS</h3>
            <p style={{ margin: 0, textAlign: 'justify' }}>
              As parcelas poderão ser reajustadas anualmente pelo índice oficial de inflação vigente.
            </p>
          </div>

          <div style={{ backgroundColor: '#e0e7ff', padding: '12px', borderRadius: '6px', marginBottom: '16px' }}>
            <h3 style={{ fontWeight: '600', color: '#5b21b6', marginBottom: '8px', fontSize: '14px' }}>🚗 CLÁUSULA QUARTA – ENTREGA</h3>
            <p style={{ margin: 0, textAlign: 'justify' }}>
              O veículo será entregue mediante o pagamento da entrada e assinatura deste contrato, 
              ficando a FINANCIADORA como proprietária fiduciária até a quitação total.
            </p>
          </div>

          <div style={{ backgroundColor: '#fee2e2', padding: '12px', borderRadius: '6px', marginBottom: '20px' }}>
            <h3 style={{ fontWeight: '600', color: '#dc2626', marginBottom: '8px', fontSize: '14px' }}>⚠️ PARÁGRAFO ÚNICO</h3>
            <p style={{ margin: 0, textAlign: 'justify' }}>
              O não pagamento de qualquer parcela na data do vencimento implicará na incidência de multa 
              de 2% sobre o valor em atraso, além de juros de mora de 1% ao mês e correção monetária.
            </p>
          </div>

          <div style={{ backgroundColor: '#f3f4f6', padding: '12px', borderRadius: '6px', marginBottom: '24px' }}>
            <h3 style={{ fontWeight: '600', color: '#374151', marginBottom: '8px', fontSize: '14px' }}>📝 DECLARAÇÃO</h3>
            <p style={{ margin: 0, textAlign: 'justify' }}>
              O FINANCIADO declara estar ciente de todas as cláusulas e condições deste contrato, 
              concordando integralmente com seus termos.
            </p>
          </div>

          {/* Signatures */}
          <div style={{ marginTop: '32px', paddingTop: '20px', borderTop: '1px solid #e5e7eb' }}>
            <div style={{ textAlign: 'center', marginBottom: '24px' }}>
              <div style={{ borderTop: '1px solid #9ca3af', paddingTop: '8px', marginTop: '40px', marginLeft: '32px', marginRight: '32px' }}>
                <p style={{ fontWeight: '600', fontSize: '14px', margin: '0 0 4px 0' }}>BELCAR INVESTCAR LTDA</p>
                <p style={{ fontSize: '12px', color: '#6b7280', margin: 0 }}>Financiadora</p>
              </div>
            </div>
            <div style={{ textAlign: 'center', marginBottom: '24px' }}>
              <div style={{ borderTop: '1px solid #9ca3af', paddingTop: '8px', marginTop: '40px', marginLeft: '32px', marginRight: '32px' }}>
                <p style={{ fontWeight: '600', fontSize: '14px', margin: '0 0 4px 0' }}>{contractData.nome.toUpperCase()}</p>
                <p style={{ fontSize: '12px', color: '#6b7280', margin: 0 }}>Financiad{contractData.cpfCnpj.length > 14 ? 'a' : 'o'}</p>
              </div>
            </div>
            <div style={{ textAlign: 'center' }}>
              <p style={{ fontSize: '12px', color: '#6b7280' }}>
                São Paulo, {new Date().toLocaleDateString('pt-BR', { 
                  day: 'numeric', 
                  month: 'long', 
                  year: 'numeric' 
                })}
              </p>
            </div>
          </div>
        </div>
      </div>

      <Modal 
        isOpen={showModal} 
        onClose={() => setShowModal(false)}
        title={modalContent.title}
      >
        <p style={{ color: '#6b7280', whiteSpace: 'pre-line' }}>{modalContent.message}</p>
        <div style={{ marginTop: '16px', textAlign: 'right' }}>
          <button
            onClick={() => setShowModal(false)}
            style={{
              backgroundColor: '#1e40af',
              color: 'white',
              border: 'none',
              padding: '8px 16px',
              borderRadius: '6px',
              cursor: 'pointer'
            }}
          >
            OK
          </button>
        </div>
      </Modal>
    </div>
  )
}

export default ContractPreview