export const sampleProposalData = {
  // Dados do Comprador
  nome: 'João Silva Santos',
  profissao: 'Engenheiro Civil',
  cpfCnpj: '123.456.789-00',
  dataNascimento: '1985-03-15',
  estadoCivil: 'Casado(a)',
  endereco: 'Rua das Flores, 123, Jardim Paulista',
  cidade: 'São Paulo',
  estado: 'SP',
  cep: '01310-100',
  email: 'joao.silva@email.com',
  telefone: '(11) 99999-9999',
  
  // Condições da Venda
  modeloBem: 'Honda Civic Touring 2024',
  codigo: 'HCV2024T001',
  valorBem: '125000.00',
  percentualEntrada: '30',
  planoMeses: '48',
  valorParcela: '2187.50',
  vencimentoDia: '10',
  
  // Recibo
  valorRecebido: '37500.00',
  percentualEquivalente: '30',
  formaPagamento: 'Dinheiro',
  banco: '',
  agencia: '',
  numeroCheque: ''
}

export const sampleProposalDataCheque = {
  // Dados do Comprador
  nome: 'Maria Oliveira Costa',
  profissao: 'Médica Pediatra',
  cpfCnpj: '987.654.321-00',
  dataNascimento: '1978-08-22',
  estadoCivil: 'Solteiro(a)',
  endereco: 'Av. Paulista, 1000, Bela Vista',
  cidade: 'São Paulo',
  estado: 'SP',
  cep: '01310-200',
  email: 'maria.costa@email.com',
  telefone: '(11) 88888-8888',
  
  // Condições da Venda
  modeloBem: 'Toyota Corolla Cross XRE 2024',
  codigo: 'TCC2024X002',
  valorBem: '98000.00',
  percentualEntrada: '25',
  planoMeses: '60',
  valorParcela: '1470.00',
  vencimentoDia: '15',
  
  // Recibo
  valorRecebido: '24500.00',
  percentualEquivalente: '25',
  formaPagamento: 'Cheque',
  banco: 'Banco do Brasil',
  agencia: '1234-5',
  numeroCheque: '000123'
}